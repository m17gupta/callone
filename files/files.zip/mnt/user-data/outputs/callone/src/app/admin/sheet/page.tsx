import {SheetLabWorkspace} from "@/components/admin/SheetLabWorkspace";
import {PageHeader} from "@/components/admin/PageHeader";
import dbConnect from "@/lib/db/connection";
import {Brand} from "@/lib/db/models/Brand";
import {Product} from "@/lib/db/models/Product";
import {Variant} from "@/lib/db/models/Variant";
import {Warehouse} from "@/lib/db/models/Warehouse";

export const dynamic = "force-dynamic";

export default async function SheetLabPage() {
  await dbConnect();

  const [brands, products, variants, warehouses] = await Promise.all([
    Brand.find({isActive: true}).sort({name: 1}).lean(),
    Product.find({status: "active"}).sort({name: 1}).limit(500).lean(),
    Variant.find({status: {$ne: "archived"}}).lean(),
    Warehouse.find({isActive: true}).sort({priority: 1}).lean(),
  ]);

  const catalogContext = {
    brands: brands.map((b) => ({id: b._id.toString(), name: b.name, code: b.code})),
    products: products.map((p) => ({
      id: p._id.toString(),
      name: p.name,
      baseSku: p.baseSku,
      category: p.category,
    })),
    skus: variants.map((v) => v.sku).filter(Boolean),
    warehouses: warehouses.map((w) => ({id: w._id.toString(), code: w.code, name: w.name})),
  };

  return (
    <div className="space-y-5">
      <PageHeader
        title="Sheet Lab"
        description="Upload any CSV/XLSX, auto-detect columns, filter with conditions, and calibrate rows against live catalog data."
      />
      <SheetLabWorkspace catalogContext={catalogContext} />
    </div>
  );
}
