'use client';

import React, {useEffect, useRef, useState} from "react";
import Link from "next/link";
import Image from "next/image";
import {usePathname} from "next/navigation";
import {signOut} from "next-auth/react";
import clsx from "clsx";
import {AnimatePresence, motion} from "framer-motion";
import {
  ChevronDown,
  Command,
  Menu,
  Moon,
  Search,
  Sun,
  X,
  Zap,
} from "lucide-react";
import {ADMIN_NAV_ITEMS, MEGA_MENU_GROUPS} from "@/lib/admin/command-center";
import {useTheme} from "../ThemeProvider";
import {MegaSearch} from "../ui/MegaSearch";

type AdminShellProps = {
  children: React.ReactNode;
  user: {
    name?: string | null;
    email?: string | null;
    role: string;
  };
};

const GROUP_ORDER = ["Catalog", "Orders", "Inventory", "Admin", "Tools"] as const;

export function AdminShell({children, user}: AdminShellProps) {
  const {theme, toggleTheme} = useTheme();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [activeMegaGroup, setActiveMegaGroup] = useState<string | null>(null);
  const megaRef = useRef<HTMLDivElement>(null);
  const pathname = usePathname();

  const visibleNavItems = ADMIN_NAV_ITEMS.filter(
    (item) => !item.roles || item.roles.includes(user.role)
  );

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 8);
    window.addEventListener("scroll", handleScroll, {passive: true});
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === "k") {
        e.preventDefault();
        setSearchOpen((prev) => !prev);
      }
      if (e.key === "Escape") setActiveMegaGroup(null);
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, []);

  useEffect(() => {
    setActiveMegaGroup(null);
  }, [pathname]);

  const activeItem =
    visibleNavItems.find((item) =>
      item.href === "/admin"
        ? pathname === "/admin"
        : pathname === item.href || pathname.startsWith(`${item.href}/`)
    ) ?? visibleNavItems[0];

  // Group nav items
  const groupedItems = GROUP_ORDER.map((group) => ({
    group,
    items: (MEGA_MENU_GROUPS[group] ?? []).filter(
      (item) => !item.roles || item.roles.includes(user.role)
    ),
  })).filter((g) => g.items.length > 0);

  const topNavGroups = groupedItems.filter(
    (g) => g.group === "Catalog" || g.group === "Orders" || g.group === "Inventory"
  );
  const adminGroups = groupedItems.filter(
    (g) => g.group === "Admin" || g.group === "Tools"
  );

  return (
    <div className="relative min-h-screen bg-[#050505] text-foreground selection:bg-primary/20 selection:text-white">
      {/* Ambient background */}
      <div className="pointer-events-none fixed inset-0 z-0">
        <div className="absolute inset-0 bg-[linear-gradient(to_bottom,rgba(10,10,10,0.95),rgba(5,5,5,1))]" />
        <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxwYXRoIGQ9Ik0wIDBoNjB2NjBIMHoiLz48cGF0aCBkPSJNNjAgMEgwdjYwaDYwVjB6TTEgMWg1OHY1OEgxVjF6IiBmaWxsPSJyZ2JhKDI1NSwyNTUsMjU1LDAuMDIpIi8+PC9nPjwvc3ZnPg==')] opacity-40" />
        <div className="absolute top-0 left-1/4 w-[600px] h-[300px] bg-primary/5 blur-[120px] rounded-full" />
        <div className="absolute top-0 right-1/4 w-[400px] h-[200px] bg-blue-600/4 blur-[100px] rounded-full" />
      </div>

      <MegaSearch isOpen={searchOpen} onClose={() => setSearchOpen(false)} role={user.role} />

      {/* Mobile overlay */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div
            initial={{opacity: 0}}
            animate={{opacity: 1}}
            exit={{opacity: 0}}
            className="fixed inset-0 bg-black/80 backdrop-blur-md z-40 md:hidden"
            onClick={() => setMobileMenuOpen(false)}
          />
        )}
      </AnimatePresence>

      {/* HEADER */}
      <header
        className={clsx(
          "sticky top-0 z-50 transition-all duration-300 border-b",
          scrolled
            ? "bg-[#080808]/95 backdrop-blur-2xl border-white/8 shadow-[0_1px_40px_rgba(0,0,0,0.6)]"
            : "bg-[#0a0a0a] border-white/6"
        )}
      >
        {/* Top bar */}
        <div className="flex h-14 items-center gap-2 px-4 xl:px-6">
          {/* Mobile menu button */}
          <button
            className="rounded-xl border border-white/10 bg-white/5 p-2 text-white/60 transition hover:text-white md:hidden"
            onClick={() => setMobileMenuOpen(true)}
          >
            <Menu size={16} />
          </button>

          {/* Logo */}
          <Link href="/admin" className="flex items-center gap-3 mr-4 shrink-0">
            <div className="flex h-9 w-[96px] items-center justify-center rounded-xl bg-white/6 border border-white/8 px-2.5">
              <Image
                src="/images/brands/callaway-logo-white.png"
                alt="Callaway"
                width={80}
                height={44}
                className="h-auto w-full object-contain"
                priority
              />
            </div>
            <div className="hidden xl:block">
              <p className="text-[10px] font-semibold uppercase tracking-[0.22em] text-white/35 leading-none">
                CallawayOne
              </p>
              <p className="text-[13px] font-semibold text-white/85 leading-tight mt-0.5">
                Admin Workspace
              </p>
            </div>
          </Link>

          {/* Desktop navigation groups */}
          <nav className="hidden md:flex items-center gap-1 flex-1 min-w-0" ref={megaRef}>
            {[...topNavGroups, ...adminGroups].map(({group, items}) => {
              const isGroupActive = items.some((item) =>
                item.href === "/admin"
                  ? pathname === "/admin"
                  : pathname === item.href || pathname.startsWith(`${item.href}/`)
              );
              const isMegaOpen = activeMegaGroup === group;

              // Single item groups → direct link
              if (items.length === 1) {
                const item = items[0];
                const isActive =
                  item.href === "/admin"
                    ? pathname === "/admin"
                    : pathname === item.href || pathname.startsWith(`${item.href}/`);
                return (
                  <Link
                    key={group}
                    href={item.href}
                    className={clsx(
                      "flex items-center gap-1.5 rounded-xl px-3.5 py-2 text-[13px] font-medium tracking-[0.01em] transition-all whitespace-nowrap",
                      isActive
                        ? "bg-white/12 text-white"
                        : "text-white/60 hover:bg-white/8 hover:text-white/90"
                    )}
                  >
                    {item.label}
                  </Link>
                );
              }

              return (
                <div
                  key={group}
                  className="relative"
                  onMouseEnter={() => setActiveMegaGroup(group)}
                  onMouseLeave={() => setActiveMegaGroup(null)}
                >
                  <button
                    className={clsx(
                      "flex items-center gap-1.5 rounded-xl px-3.5 py-2 text-[13px] font-medium tracking-[0.01em] transition-all whitespace-nowrap",
                      isGroupActive || isMegaOpen
                        ? "bg-white/12 text-white"
                        : "text-white/60 hover:bg-white/8 hover:text-white/90"
                    )}
                  >
                    {group}
                    <ChevronDown
                      size={13}
                      className={clsx(
                        "transition-transform duration-200",
                        isMegaOpen ? "rotate-180 text-primary" : "text-white/40"
                      )}
                    />
                  </button>

                  {/* Mega dropdown */}
                  <AnimatePresence>
                    {isMegaOpen && (
                      <motion.div
                        initial={{opacity: 0, y: -4, scale: 0.98}}
                        animate={{opacity: 1, y: 0, scale: 1}}
                        exit={{opacity: 0, y: -4, scale: 0.98}}
                        transition={{duration: 0.15, ease: "easeOut"}}
                        className="absolute top-full left-0 mt-1.5 min-w-[280px] rounded-2xl border border-white/10 bg-[#0d0d0d] shadow-[0_20px_60px_rgba(0,0,0,0.7)] overflow-hidden"
                        style={{backdropFilter: "blur(24px)"}}
                      >
                        <div className="p-1.5">
                          <div className="px-3 py-2 mb-1 border-b border-white/6">
                            <p className="text-[10px] font-semibold uppercase tracking-[0.22em] text-white/30">
                              {group}
                            </p>
                          </div>
                          {items.map((item) => {
                            const Icon = item.icon;
                            const isActive =
                              item.href === "/admin"
                                ? pathname === "/admin"
                                : pathname === item.href ||
                                  pathname.startsWith(`${item.href}/`);
                            return (
                              <Link
                                key={item.href}
                                href={item.href}
                                className={clsx(
                                  "flex items-start gap-3 rounded-xl px-3 py-2.5 transition-all",
                                  isActive
                                    ? "bg-primary/15 text-white"
                                    : "text-white/70 hover:bg-white/6 hover:text-white"
                                )}
                              >
                                <div
                                  className={clsx(
                                    "mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-lg",
                                    isActive ? "bg-primary/20 text-primary" : "bg-white/6 text-white/50"
                                  )}
                                >
                                  <Icon size={15} />
                                </div>
                                <div className="min-w-0">
                                  <div className="flex items-center gap-2">
                                    <p className="text-[13px] font-semibold leading-tight">{item.label}</p>
                                    {item.badge && (
                                      <span className="rounded-full bg-primary/20 border border-primary/30 px-1.5 py-0.5 text-[9px] font-bold uppercase tracking-wider text-primary">
                                        {item.badge}
                                      </span>
                                    )}
                                  </div>
                                  <p className="mt-0.5 text-[11px] leading-relaxed text-white/40 line-clamp-1">
                                    {item.description}
                                  </p>
                                </div>
                              </Link>
                            );
                          })}
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              );
            })}
          </nav>

          {/* Right controls */}
          <div className="ml-auto flex items-center gap-1.5 shrink-0">
            {/* Search trigger */}
            <button
              onClick={() => setSearchOpen(true)}
              className="hidden md:flex items-center gap-2 rounded-xl border border-white/10 bg-white/5 px-3 py-2 text-[12px] text-white/45 transition hover:border-white/20 hover:text-white/70 group"
            >
              <Search size={13} className="text-white/40 group-hover:text-white/60" />
              <span className="hidden lg:block">Search</span>
              <span className="hidden lg:flex items-center gap-1 rounded-lg border border-white/10 bg-white/5 px-2 py-0.5 text-[10px] font-semibold text-white/35">
                <Command size={9} />K
              </span>
            </button>

            <button
              onClick={() => setSearchOpen(true)}
              className="md:hidden flex h-9 w-9 items-center justify-center rounded-xl border border-white/10 bg-white/5 text-white/60 transition hover:text-white"
            >
              <Search size={15} />
            </button>

            {/* Theme toggle */}
            <button
              onClick={toggleTheme}
              className="flex h-9 w-9 items-center justify-center rounded-xl border border-white/10 bg-white/5 text-white/55 transition hover:text-white"
              aria-label="Toggle theme"
            >
              {theme === "dark" ? <Sun size={15} /> : <Moon size={15} />}
            </button>

            {/* Sign out */}
            <button
              onClick={() => signOut({callbackUrl: "/login"})}
              className="hidden md:flex items-center gap-1.5 rounded-xl border border-white/10 bg-white/5 px-3 py-2 text-[12px] font-medium text-white/55 transition hover:border-white/20 hover:text-white"
            >
              Sign out
            </button>
          </div>
        </div>

        {/* Secondary nav bar — current page breadcrumb + quick actions */}
        <div className="hidden md:flex h-10 items-center gap-3 border-t border-white/4 px-4 xl:px-6">
          <div className="flex items-center gap-2 text-[11px] text-white/35">
            <span className="font-medium text-white/55">Admin</span>
            <span>/</span>
            <span className="text-white/70 font-medium">{activeItem?.label ?? "Dashboard"}</span>
          </div>
          <div className="ml-auto flex items-center gap-2">
            <Zap size={11} className="text-primary/60" />
            <span className="text-[10px] text-white/25 font-medium tracking-wider uppercase">
              CallawayOne · v0.1 · {user.role.replace("_", " ")}
            </span>
          </div>
        </div>
      </header>

      {/* Mobile drawer */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.aside
            initial={{x: -20, opacity: 0}}
            animate={{x: 0, opacity: 1}}
            exit={{x: -20, opacity: 0}}
            className="fixed left-2 top-2 z-50 w-[280px] rounded-2xl border border-white/10 bg-[#0a0a0a] p-3 text-white shadow-[0_30px_80px_rgba(0,0,0,0.8)] md:hidden"
            style={{backdropFilter: "blur(32px)"}}
          >
            <div className="mb-3 flex items-center justify-between">
              <div className="flex h-9 w-[86px] items-center justify-center rounded-xl bg-white/6 border border-white/8 px-2">
                <Image
                  src="/images/brands/callaway-logo-white.png"
                  alt="Callaway"
                  width={70}
                  height={38}
                  className="h-auto w-full object-contain"
                />
              </div>
              <button
                className="rounded-xl border border-white/10 bg-white/5 p-2 text-white/60"
                onClick={() => setMobileMenuOpen(false)}
              >
                <X size={16} />
              </button>
            </div>

            <button
              onClick={() => {
                setSearchOpen(true);
                setMobileMenuOpen(false);
              }}
              className="mb-3 flex h-10 w-full items-center gap-2 rounded-xl border border-white/10 bg-white/5 px-3 text-left text-[12px] text-white/45"
            >
              <Search size={13} />
              Search routes and actions
              <Command size={11} className="ml-auto" />
            </button>

            <div className="space-y-0.5 max-h-[60vh] overflow-y-auto">
              {visibleNavItems.map((item) => {
                const Icon = item.icon;
                const isActive =
                  item.href === "/admin"
                    ? pathname === "/admin"
                    : pathname === item.href || pathname.startsWith(`${item.href}/`);
                return (
                  <Link
                    key={item.href}
                    href={item.href}
                    onClick={() => setMobileMenuOpen(false)}
                    className={clsx(
                      "flex items-center gap-2.5 rounded-xl px-3 py-2.5 text-[13px] font-medium transition",
                      isActive
                        ? "bg-white/12 text-white"
                        : "text-white/55 hover:bg-white/7 hover:text-white"
                    )}
                  >
                    <Icon size={15} />
                    {item.label}
                    {item.badge && (
                      <span className="ml-auto rounded-full bg-primary/20 border border-primary/30 px-1.5 py-0.5 text-[9px] font-bold uppercase tracking-wider text-primary">
                        {item.badge}
                      </span>
                    )}
                  </Link>
                );
              })}
            </div>

            <div className="mt-3 border-t border-white/6 pt-3">
              <button
                onClick={() => signOut({callbackUrl: "/login"})}
                className="w-full rounded-xl border border-white/10 bg-white/5 py-2 text-[12px] font-medium text-white/55 transition hover:text-white"
              >
                Sign out
              </button>
            </div>
          </motion.aside>
        )}
      </AnimatePresence>

      {/* Main content — full width */}
      <main className="relative z-10 min-h-[calc(100vh-96px)] px-3 pb-8 pt-4 xl:px-5">
        <motion.div
          initial={{opacity: 0, y: 8}}
          animate={{opacity: 1, y: 0}}
          transition={{duration: 0.28, ease: "easeOut"}}
          className="w-full"
        >
          {children}
        </motion.div>
      </main>
    </div>
  );
}
