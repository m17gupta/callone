"use client";

import {useCallback, useMemo, useState} from "react";
import Link from "next/link";
import {
  ArrowUpDown,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  ChevronsUpDown,
  Download,
  Filter,
  FilterX,
  MoreHorizontal,
  Package,
  Plus,
  Search,
  SlidersHorizontal,
  Trash2,
  X,
} from "lucide-react";
import clsx from "clsx";
import {deleteProduct} from "@/lib/actions/products";

type ProductRow = {
  id: string;
  name: string;
  baseSku: string;
  category: string;
  subcategory?: string;
  productType: string;
  status: string;
  brand: string;
  brandId: string;
  variantCount: number;
  stockAvailable: number;
  listPrice: number;
};

type SortDir = "asc" | "desc" | null;
type SortKey = keyof ProductRow;

type FilterState = {
  search: string;
  status: string[];
  brand: string[];
  productType: string[];
  category: string[];
  stockMin: string;
  stockMax: string;
};

const EMPTY_FILTERS: FilterState = {
  search: "",
  status: [],
  brand: [],
  productType: [],
  category: [],
  stockMin: "",
  stockMax: "",
};

const STATUS_COLORS: Record<string, string> = {
  active: "text-emerald-400 bg-emerald-400/10 border-emerald-400/20",
  draft: "text-amber-400 bg-amber-400/10 border-amber-400/20",
  archived: "text-white/30 bg-white/5 border-white/10",
};

const PAGE_SIZES = [20, 50, 100, 200];

type Props = {
  products: ProductRow[];
  brands: Array<{id: string; label: string}>;
  categories: string[];
  productTypes: string[];
};

export function ProductCatalog({products, brands, categories, productTypes}: Props) {
  const [filters, setFilters] = useState<FilterState>(EMPTY_FILTERS);
  const [sortKey, setSortKey] = useState<SortKey>("name");
  const [sortDir, setSortDir] = useState<SortDir>("asc");
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(50);
  const [filterPanelOpen, setFilterPanelOpen] = useState(false);
  const [columnMenuOpen, setColumnMenuOpen] = useState(false);
  const [visibleCols, setVisibleCols] = useState<Set<string>>(
    new Set(["name", "brand", "category", "variants", "stock", "status", "actions"])
  );

  const setFilter = useCallback(
    <K extends keyof FilterState>(key: K, value: FilterState[K]) => {
      setFilters((prev) => ({...prev, [key]: value}));
      setPage(1);
    },
    []
  );

  const toggleMultiFilter = useCallback(
    (key: "status" | "brand" | "productType" | "category", value: string) => {
      setFilters((prev) => {
        const arr = prev[key];
        return {
          ...prev,
          [key]: arr.includes(value) ? arr.filter((v) => v !== value) : [...arr, value],
        };
      });
      setPage(1);
    },
    []
  );

  const clearFilter = useCallback(
    (key: keyof FilterState) => {
      setFilter(key, EMPTY_FILTERS[key] as FilterState[typeof key]);
    },
    [setFilter]
  );

  const clearAllFilters = useCallback(() => {
    setFilters(EMPTY_FILTERS);
    setPage(1);
  }, []);

  const handleSort = useCallback(
    (key: SortKey) => {
      if (sortKey === key) {
        setSortDir((d) => (d === "asc" ? "desc" : d === "desc" ? null : "asc"));
        if (sortDir === null) setSortKey("name");
      } else {
        setSortKey(key);
        setSortDir("asc");
      }
    },
    [sortKey, sortDir]
  );

  const filteredProducts = useMemo(() => {
    let result = products;

    if (filters.search) {
      const q = filters.search.toLowerCase();
      result = result.filter(
        (p) =>
          p.name.toLowerCase().includes(q) ||
          p.baseSku.toLowerCase().includes(q) ||
          p.category.toLowerCase().includes(q) ||
          p.brand.toLowerCase().includes(q)
      );
    }

    if (filters.status.length) {
      result = result.filter((p) => filters.status.includes(p.status));
    }
    if (filters.brand.length) {
      result = result.filter((p) => filters.brand.includes(p.brandId));
    }
    if (filters.productType.length) {
      result = result.filter((p) => filters.productType.includes(p.productType));
    }
    if (filters.category.length) {
      result = result.filter((p) => filters.category.includes(p.category));
    }
    if (filters.stockMin) {
      result = result.filter((p) => p.stockAvailable >= Number(filters.stockMin));
    }
    if (filters.stockMax) {
      result = result.filter((p) => p.stockAvailable <= Number(filters.stockMax));
    }

    if (sortDir && sortKey) {
      result = [...result].sort((a, b) => {
        const av = a[sortKey];
        const bv = b[sortKey];
        const cmp =
          typeof av === "number" && typeof bv === "number"
            ? av - bv
            : String(av).localeCompare(String(bv));
        return sortDir === "asc" ? cmp : -cmp;
      });
    }

    return result;
  }, [products, filters, sortKey, sortDir]);

  const totalPages = Math.max(1, Math.ceil(filteredProducts.length / pageSize));
  const paginatedProducts = filteredProducts.slice((page - 1) * pageSize, page * pageSize);

  const activeFilterCount = useMemo(() => {
    let count = 0;
    if (filters.search) count++;
    if (filters.status.length) count++;
    if (filters.brand.length) count++;
    if (filters.productType.length) count++;
    if (filters.category.length) count++;
    if (filters.stockMin || filters.stockMax) count++;
    return count;
  }, [filters]);

  const allPageSelected =
    paginatedProducts.length > 0 &&
    paginatedProducts.every((p) => selectedIds.has(p.id));

  const toggleAll = () => {
    if (allPageSelected) {
      setSelectedIds((s) => {
        const next = new Set(s);
        paginatedProducts.forEach((p) => next.delete(p.id));
        return next;
      });
    } else {
      setSelectedIds((s) => {
        const next = new Set(s);
        paginatedProducts.forEach((p) => next.add(p.id));
        return next;
      });
    }
  };

  const money = new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    maximumFractionDigits: 0,
  });

  const SortIcon = ({col}: {col: SortKey}) => {
    if (sortKey !== col) return <ChevronsUpDown size={12} className="text-white/20" />;
    if (sortDir === "asc") return <ArrowUpDown size={12} className="text-primary rotate-0" />;
    if (sortDir === "desc") return <ArrowUpDown size={12} className="text-primary rotate-180" />;
    return <ChevronsUpDown size={12} className="text-white/20" />;
  };

  return (
    <div className="flex flex-col gap-0 rounded-2xl border border-white/8 bg-[#0d0d0d] overflow-hidden">
      {/* ── TOOLBAR ── */}
      <div className="flex flex-col gap-2 border-b border-white/8 px-4 py-3 lg:flex-row lg:items-center lg:gap-3">
        {/* Search */}
        <div className="relative flex-1 min-w-0 max-w-[420px]">
          <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-white/30" />
          <input
            type="text"
            placeholder="Search name, SKU, category, brand…"
            value={filters.search}
            onChange={(e) => setFilter("search", e.target.value)}
            className="h-9 w-full rounded-xl border border-white/10 bg-white/4 pl-9 pr-3 text-[13px] text-white placeholder:text-white/25 outline-none focus:border-primary/40 focus:bg-white/6 transition-all"
          />
          {filters.search && (
            <button
              onClick={() => clearFilter("search")}
              className="absolute right-2.5 top-1/2 -translate-y-1/2 text-white/30 hover:text-white/70"
            >
              <X size={13} />
            </button>
          )}
        </div>

        <div className="flex items-center gap-1.5 flex-wrap">
          {/* Quick status pills */}
          {["active", "draft", "archived"].map((s) => (
            <button
              key={s}
              onClick={() => toggleMultiFilter("status", s)}
              className={clsx(
                "rounded-lg border px-2.5 py-1 text-[11px] font-semibold uppercase tracking-wider transition-all",
                filters.status.includes(s)
                  ? STATUS_COLORS[s] + " border-opacity-100"
                  : "border-white/8 bg-white/3 text-white/35 hover:border-white/16 hover:text-white/60"
              )}
            >
              {s}
            </button>
          ))}

          <div className="w-px h-5 bg-white/8" />

          {/* Advanced filter toggle */}
          <button
            onClick={() => setFilterPanelOpen((v) => !v)}
            className={clsx(
              "flex items-center gap-1.5 rounded-xl border px-3 py-1.5 text-[12px] font-medium transition-all",
              filterPanelOpen || activeFilterCount > 0
                ? "border-primary/40 bg-primary/10 text-primary"
                : "border-white/10 bg-white/4 text-white/50 hover:border-white/20 hover:text-white/80"
            )}
          >
            <SlidersHorizontal size={13} />
            Filters
            {activeFilterCount > 0 && (
              <span className="flex h-4 w-4 items-center justify-center rounded-full bg-primary text-[9px] font-bold text-white">
                {activeFilterCount}
              </span>
            )}
          </button>

          {activeFilterCount > 0 && (
            <button
              onClick={clearAllFilters}
              className="flex items-center gap-1 rounded-xl border border-white/8 px-2.5 py-1.5 text-[11px] text-white/35 hover:text-white/60 transition"
            >
              <FilterX size={12} />
              Clear
            </button>
          )}
        </div>

        <div className="ml-auto flex items-center gap-1.5 shrink-0">
          {selectedIds.size > 0 && (
            <div className="flex items-center gap-1.5 rounded-xl border border-white/10 bg-white/4 px-2.5 py-1.5">
              <span className="text-[12px] font-medium text-white/60">
                {selectedIds.size} selected
              </span>
              <div className="w-px h-4 bg-white/10" />
              <button className="text-[11px] font-medium text-danger hover:text-red-300 transition">
                Delete
              </button>
            </div>
          )}

          <a
            href="/api/admin/export/products"
            className="flex items-center gap-1.5 rounded-xl border border-white/10 bg-white/4 px-3 py-1.5 text-[12px] font-medium text-white/50 hover:border-white/20 hover:text-white/80 transition"
          >
            <Download size={13} />
            Export
          </a>

          <Link
            href="/admin/products/new"
            className="flex items-center gap-1.5 rounded-xl bg-primary px-3 py-1.5 text-[12px] font-semibold text-white shadow-[0_8px_20px_rgba(47,127,244,0.25)] hover:bg-primary/90 transition"
          >
            <Plus size={13} />
            New product
          </Link>
        </div>
      </div>

      {/* ── ADVANCED FILTER PANEL ── */}
      <AnimatePresence>
        {filterPanelOpen && (
          <motion.div
            initial={{height: 0, opacity: 0}}
            animate={{height: "auto", opacity: 1}}
            exit={{height: 0, opacity: 0}}
            transition={{duration: 0.2}}
            className="overflow-hidden border-b border-white/8"
          >
            <div className="p-4 grid gap-4 md:grid-cols-2 xl:grid-cols-4">
              {/* Brand filter */}
              <div>
                <p className="mb-2 text-[10px] font-semibold uppercase tracking-[0.2em] text-white/30">
                  Brand
                </p>
                <div className="flex flex-wrap gap-1.5">
                  {brands.map((b) => (
                    <button
                      key={b.id}
                      onClick={() => toggleMultiFilter("brand", b.id)}
                      className={clsx(
                        "rounded-lg border px-2.5 py-1 text-[11px] font-medium transition-all",
                        filters.brand.includes(b.id)
                          ? "border-primary/40 bg-primary/12 text-primary"
                          : "border-white/8 bg-white/3 text-white/40 hover:border-white/15 hover:text-white/65"
                      )}
                    >
                      {b.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Category filter */}
              <div>
                <p className="mb-2 text-[10px] font-semibold uppercase tracking-[0.2em] text-white/30">
                  Category
                </p>
                <div className="flex flex-wrap gap-1.5">
                  {categories.slice(0, 12).map((cat) => (
                    <button
                      key={cat}
                      onClick={() => toggleMultiFilter("category", cat)}
                      className={clsx(
                        "rounded-lg border px-2.5 py-1 text-[11px] font-medium transition-all",
                        filters.category.includes(cat)
                          ? "border-primary/40 bg-primary/12 text-primary"
                          : "border-white/8 bg-white/3 text-white/40 hover:border-white/15 hover:text-white/65"
                      )}
                    >
                      {cat}
                    </button>
                  ))}
                </div>
              </div>

              {/* Product type */}
              <div>
                <p className="mb-2 text-[10px] font-semibold uppercase tracking-[0.2em] text-white/30">
                  Type
                </p>
                <div className="flex flex-wrap gap-1.5">
                  {productTypes.map((t) => (
                    <button
                      key={t}
                      onClick={() => toggleMultiFilter("productType", t)}
                      className={clsx(
                        "rounded-lg border px-2.5 py-1 text-[11px] font-medium transition-all capitalize",
                        filters.productType.includes(t)
                          ? "border-primary/40 bg-primary/12 text-primary"
                          : "border-white/8 bg-white/3 text-white/40 hover:border-white/15 hover:text-white/65"
                      )}
                    >
                      {t}
                    </button>
                  ))}
                </div>
              </div>

              {/* Stock range */}
              <div>
                <p className="mb-2 text-[10px] font-semibold uppercase tracking-[0.2em] text-white/30">
                  Available stock range
                </p>
                <div className="flex items-center gap-2">
                  <input
                    type="number"
                    placeholder="Min"
                    value={filters.stockMin}
                    onChange={(e) => setFilter("stockMin", e.target.value)}
                    className="h-8 w-full rounded-lg border border-white/10 bg-white/4 px-2 text-[12px] text-white outline-none focus:border-primary/40 transition"
                  />
                  <span className="text-white/25 text-[11px]">—</span>
                  <input
                    type="number"
                    placeholder="Max"
                    value={filters.stockMax}
                    onChange={(e) => setFilter("stockMax", e.target.value)}
                    className="h-8 w-full rounded-lg border border-white/10 bg-white/4 px-2 text-[12px] text-white outline-none focus:border-primary/40 transition"
                  />
                </div>
              </div>
            </div>

            {/* Applied filter chips */}
            {activeFilterCount > 0 && (
              <div className="flex items-center gap-2 flex-wrap px-4 pb-3">
                <span className="text-[10px] text-white/25 font-semibold uppercase tracking-wider">
                  Applied:
                </span>
                {filters.search && (
                  <Chip label={`Search: "${filters.search}"`} onRemove={() => clearFilter("search")} />
                )}
                {filters.status.map((s) => (
                  <Chip key={s} label={`Status: ${s}`} onRemove={() => toggleMultiFilter("status", s)} />
                ))}
                {filters.brand.map((b) => (
                  <Chip
                    key={b}
                    label={`Brand: ${brands.find((br) => br.id === b)?.label ?? b}`}
                    onRemove={() => toggleMultiFilter("brand", b)}
                  />
                ))}
                {filters.productType.map((t) => (
                  <Chip key={t} label={`Type: ${t}`} onRemove={() => toggleMultiFilter("productType", t)} />
                ))}
                {filters.category.map((c) => (
                  <Chip key={c} label={`Cat: ${c}`} onRemove={() => toggleMultiFilter("category", c)} />
                ))}
                {(filters.stockMin || filters.stockMax) && (
                  <Chip
                    label={`Stock: ${filters.stockMin || "0"}–${filters.stockMax || "∞"}`}
                    onRemove={() => {
                      clearFilter("stockMin");
                      clearFilter("stockMax");
                    }}
                  />
                )}
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>

      {/* ── RESULTS META ── */}
      <div className="flex items-center justify-between px-4 py-2 border-b border-white/6 bg-white/[0.01]">
        <p className="text-[11px] text-white/30">
          <span className="text-white/60 font-semibold">{filteredProducts.length}</span> products
          {activeFilterCount > 0 && (
            <span> · filtered from <span className="text-white/50">{products.length}</span> total</span>
          )}
        </p>
        <div className="flex items-center gap-2">
          <span className="text-[11px] text-white/25">Rows per page:</span>
          <select
            value={pageSize}
            onChange={(e) => {
              setPageSize(Number(e.target.value));
              setPage(1);
            }}
            className="h-7 rounded-lg border border-white/10 bg-white/5 px-2 text-[11px] text-white/60 outline-none"
          >
            {PAGE_SIZES.map((s) => (
              <option key={s} value={s}>{s}</option>
            ))}
          </select>
        </div>
      </div>

      {/* ── TABLE ── */}
      <div className="overflow-auto">
        <table className="min-w-full text-[13px]">
          <thead className="sticky top-0 z-20 bg-[#0a0a0a] border-b border-white/8">
            <tr>
              <th className="w-10 px-3 py-3">
                <input
                  type="checkbox"
                  checked={allPageSelected}
                  onChange={toggleAll}
                  className="h-3.5 w-3.5 rounded border-white/20 bg-white/5 accent-primary cursor-pointer"
                />
              </th>
              <SortableTh label="Product" col="name" current={sortKey} dir={sortDir} onSort={handleSort} />
              <SortableTh label="Brand" col="brand" current={sortKey} dir={sortDir} onSort={handleSort} />
              <SortableTh label="Category" col="category" current={sortKey} dir={sortDir} onSort={handleSort} />
              <SortableTh label="Type" col="productType" current={sortKey} dir={sortDir} onSort={handleSort} />
              <SortableTh label="Variants" col="variantCount" current={sortKey} dir={sortDir} onSort={handleSort} align="right" />
              <SortableTh label="Available" col="stockAvailable" current={sortKey} dir={sortDir} onSort={handleSort} align="right" />
              <SortableTh label="List price" col="listPrice" current={sortKey} dir={sortDir} onSort={handleSort} align="right" />
              <SortableTh label="Status" col="status" current={sortKey} dir={sortDir} onSort={handleSort} />
              <th className="px-4 py-3 text-right text-[10px] font-semibold uppercase tracking-[0.18em] text-white/25">
                Actions
              </th>
            </tr>
          </thead>
          <tbody>
            {paginatedProducts.length === 0 ? (
              <tr>
                <td colSpan={10} className="px-4 py-16 text-center">
                  <div className="flex flex-col items-center gap-3">
                    <div className="flex h-12 w-12 items-center justify-center rounded-2xl border border-white/8 bg-white/3">
                      <Package size={20} className="text-white/20" />
                    </div>
                    <p className="text-[13px] text-white/30">No products match your filters</p>
                    {activeFilterCount > 0 && (
                      <button
                        onClick={clearAllFilters}
                        className="text-[12px] text-primary hover:underline"
                      >
                        Clear all filters
                      </button>
                    )}
                  </div>
                </td>
              </tr>
            ) : (
              paginatedProducts.map((product) => {
                const selected = selectedIds.has(product.id);
                return (
                  <tr
                    key={product.id}
                    className={clsx(
                      "group border-b border-white/4 transition-colors",
                      selected
                        ? "bg-primary/6"
                        : "hover:bg-white/[0.025]"
                    )}
                  >
                    <td className="w-10 px-3 py-3">
                      <input
                        type="checkbox"
                        checked={selected}
                        onChange={() =>
                          setSelectedIds((s) => {
                            const next = new Set(s);
                            if (selected) next.delete(product.id);
                            else next.add(product.id);
                            return next;
                          })
                        }
                        className="h-3.5 w-3.5 rounded border-white/20 bg-white/5 accent-primary cursor-pointer"
                      />
                    </td>
                    <td className="px-4 py-3">
                      <div className="font-semibold text-white/90 leading-tight">{product.name}</div>
                      <div className="mt-0.5 font-mono text-[11px] text-white/30">{product.baseSku}</div>
                    </td>
                    <td className="px-4 py-3 text-white/55 text-[12px]">{product.brand}</td>
                    <td className="px-4 py-3">
                      <span className="text-[11px] text-white/45">{product.category}</span>
                      {product.subcategory && (
                        <span className="ml-1 text-[10px] text-white/25">/ {product.subcategory}</span>
                      )}
                    </td>
                    <td className="px-4 py-3">
                      <span className="rounded-lg border border-white/8 bg-white/4 px-2 py-0.5 text-[10px] font-medium capitalize text-white/45">
                        {product.productType}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-right font-mono text-[12px] text-white/60">
                      {product.variantCount}
                    </td>
                    <td className="px-4 py-3 text-right">
                      <span
                        className={clsx(
                          "font-mono text-[12px]",
                          product.stockAvailable === 0
                            ? "text-red-400/70"
                            : product.stockAvailable < 10
                            ? "text-amber-400/70"
                            : "text-white/60"
                        )}
                      >
                        {product.stockAvailable}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-right font-mono text-[12px] text-white/50">
                      {product.listPrice > 0 ? money.format(product.listPrice) : "—"}
                    </td>
                    <td className="px-4 py-3">
                      <span
                        className={clsx(
                          "inline-flex items-center rounded-lg border px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wider",
                          STATUS_COLORS[product.status] ?? "border-white/8 bg-white/4 text-white/40"
                        )}
                      >
                        {product.status}
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center justify-end gap-1.5 opacity-0 group-hover:opacity-100 transition-opacity">
                        <Link
                          href={`/admin/products/${product.id}/edit`}
                          className="rounded-lg border border-white/10 bg-white/5 px-2.5 py-1 text-[11px] font-semibold text-primary hover:bg-primary/10 transition"
                        >
                          Edit
                        </Link>
                        <form action={deleteProduct}>
                          <input type="hidden" name="id" value={product.id} />
                          <button
                            type="submit"
                            className="flex h-6 w-6 items-center justify-center rounded-lg border border-white/8 bg-white/4 text-white/30 hover:border-red-400/30 hover:bg-red-400/10 hover:text-red-400 transition"
                          >
                            <Trash2 size={11} />
                          </button>
                        </form>
                      </div>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>

      {/* ── PAGINATION ── */}
      {totalPages > 1 && (
        <div className="flex items-center justify-between border-t border-white/8 px-4 py-3">
          <p className="text-[11px] text-white/30">
            Page <span className="text-white/55 font-semibold">{page}</span> of{" "}
            <span className="text-white/55 font-semibold">{totalPages}</span>
            <span className="ml-2 text-white/20">
              ({(page - 1) * pageSize + 1}–{Math.min(page * pageSize, filteredProducts.length)} of {filteredProducts.length})
            </span>
          </p>
          <div className="flex items-center gap-1">
            <PageBtn onClick={() => setPage(1)} disabled={page === 1} label="«" />
            <PageBtn onClick={() => setPage((p) => p - 1)} disabled={page === 1} label="‹" />
            {Array.from({length: Math.min(7, totalPages)}, (_, i) => {
              let pg: number;
              if (totalPages <= 7) {
                pg = i + 1;
              } else if (page <= 4) {
                pg = i + 1;
              } else if (page >= totalPages - 3) {
                pg = totalPages - 6 + i;
              } else {
                pg = page - 3 + i;
              }
              if (pg < 1 || pg > totalPages) return null;
              return (
                <button
                  key={pg}
                  onClick={() => setPage(pg)}
                  className={clsx(
                    "flex h-7 min-w-7 items-center justify-center rounded-lg border px-2 text-[11px] font-semibold transition",
                    pg === page
                      ? "border-primary/40 bg-primary/15 text-primary"
                      : "border-white/8 bg-white/3 text-white/35 hover:border-white/16 hover:text-white/65"
                  )}
                >
                  {pg}
                </button>
              );
            })}
            <PageBtn onClick={() => setPage((p) => p + 1)} disabled={page === totalPages} label="›" />
            <PageBtn onClick={() => setPage(totalPages)} disabled={page === totalPages} label="»" />
          </div>
        </div>
      )}
    </div>
  );
}

function Chip({label, onRemove}: {label: string; onRemove: () => void}) {
  return (
    <span className="flex items-center gap-1 rounded-lg border border-white/10 bg-white/5 px-2 py-1 text-[11px] font-medium text-white/55">
      {label}
      <button
        onClick={onRemove}
        className="ml-0.5 text-white/30 hover:text-white/70 transition"
      >
        <X size={11} />
      </button>
    </span>
  );
}

function SortableTh({
  label,
  col,
  current,
  dir,
  onSort,
  align = "left",
}: {
  label: string;
  col: SortKey;
  current: SortKey;
  dir: SortDir;
  onSort: (k: SortKey) => void;
  align?: "left" | "right";
}) {
  const isActive = current === col && dir !== null;
  return (
    <th
      className={clsx(
        "px-4 py-3 text-[10px] font-semibold uppercase tracking-[0.18em] cursor-pointer select-none transition-colors whitespace-nowrap",
        align === "right" ? "text-right" : "text-left",
        isActive ? "text-primary" : "text-white/30 hover:text-white/55"
      )}
      onClick={() => onSort(col)}
    >
      <span className={clsx("inline-flex items-center gap-1.5", align === "right" && "flex-row-reverse")}>
        {label}
        {isActive ? (
          <ArrowUpDown
            size={11}
            className={clsx("transition-transform", dir === "desc" && "rotate-180")}
          />
        ) : (
          <ChevronsUpDown size={11} className="text-white/15" />
        )}
      </span>
    </th>
  );
}

function PageBtn({
  onClick,
  disabled,
  label,
}: {
  onClick: () => void;
  disabled: boolean;
  label: string;
}) {
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      className="flex h-7 min-w-7 items-center justify-center rounded-lg border border-white/8 bg-white/3 text-[12px] text-white/30 transition hover:border-white/16 hover:text-white/65 disabled:opacity-25 disabled:cursor-not-allowed"
    >
      {label}
    </button>
  );
}

// Re-export AnimatePresence from framer-motion for use in this file
import {AnimatePresence, motion} from "framer-motion";
