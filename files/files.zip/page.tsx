import {PageHeader} from "@/components/admin/PageHeader";
import {ProductCatalog} from "@/components/admin/ProductCatalog";
import dbConnect from "@/lib/db/connection";
import {Brand} from "@/lib/db/models/Brand";
import {InventoryLevel} from "@/lib/db/models/InventoryLevel";
import {Product} from "@/lib/db/models/Product";
import {Variant} from "@/lib/db/models/Variant";

export const dynamic = "force-dynamic";

export default async function ProductsPage() {
  await dbConnect();

  const [products, brands, variants, inventoryLevels] = await Promise.all([
    Product.find().sort({updatedAt: -1}).lean(),
    Brand.find().lean(),
    Variant.find().lean(),
    InventoryLevel.find().lean(),
  ]);

  const brandMap = new Map(brands.map((b) => [b._id.toString(), b.name]));

  const variantMap = new Map<string, typeof variants>();
  for (const v of variants) {
    const pid = String(v.productId);
    const existing = variantMap.get(pid) ?? [];
    existing.push(v);
    variantMap.set(pid, existing);
  }

  const inventoryMap = new Map<string, number>();
  for (const inv of inventoryLevels) {
    const vid = String(inv.variantId);
    inventoryMap.set(vid, (inventoryMap.get(vid) ?? 0) + (inv.available ?? 0));
  }

  const productRows = products.map((p) => {
    const productVariants = variantMap.get(p._id.toString()) ?? [];
    const stockAvailable = productVariants.reduce(
      (sum, v) => sum + (inventoryMap.get(v._id.toString()) ?? 0),
      0
    );
    return {
      id: p._id.toString(),
      name: p.name ?? "",
      baseSku: p.baseSku ?? "",
      category: p.category ?? "",
      subcategory: p.subcategory ?? "",
      productType: p.productType ?? "hardgoods",
      status: p.status ?? "draft",
      brand: brandMap.get(String(p.brandId)) ?? "Unknown brand",
      brandId: String(p.brandId),
      variantCount: productVariants.length,
      stockAvailable,
      listPrice: p.listPrice ?? 0,
    };
  });

  const brandOptions = brands.map((b) => ({id: b._id.toString(), label: b.name}));

  const categories = [...new Set(products.map((p) => p.category).filter(Boolean))].sort() as string[];
  const productTypes = [...new Set(products.map((p) => p.productType).filter(Boolean))].sort() as string[];

  return (
    <div className="space-y-5">
      <PageHeader
        title="Products"
        description="Unified brand-aware product catalog and variants."
      />
      <ProductCatalog
        products={productRows}
        brands={brandOptions}
        categories={categories}
        productTypes={productTypes}
      />
    </div>
  );
}
