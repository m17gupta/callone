import {
  BarChart3,
  Box,
  Building2,
  ClipboardList,
  Database,
  FileCog,
  FileSpreadsheet,
  LayoutDashboard,
  Package,
  Settings2,
  ShoppingBag,
  Table2,
  Upload,
  Users,
  Warehouse,
} from "lucide-react";

export type AdminCommandGroup = "Navigate" | "Create" | "Operations";

export type AdminNavItem = {
  href: string;
  label: string;
  description: string;
  icon: React.ComponentType<{size?: number; className?: string}>;
  group: "Catalog" | "Inventory" | "Orders" | "Admin" | "Tools";
  roles?: string[];
  badge?: string;
};

export type AdminCommandItem = {
  id: string;
  href: string;
  label: string;
  description: string;
  icon: React.ComponentType<{size?: number; className?: string}>;
  group: AdminCommandGroup;
  keywords: string[];
  roles?: string[];
};

export const ADMIN_NAV_ITEMS: AdminNavItem[] = [
  {
    href: "/admin",
    label: "Dashboard",
    description: "Live stats, KPIs, pending approvals, and system health.",
    icon: LayoutDashboard,
    group: "Admin",
  },
  {
    href: "/admin/orders",
    label: "Orders",
    description: "Order pipeline, approvals, discount-aware totals.",
    icon: ShoppingBag,
    group: "Orders",
  },
  {
    href: "/admin/products",
    label: "Products",
    description: "Catalog explorer — variants, stock, brand-aware filtering.",
    icon: Package,
    group: "Catalog",
  },
  {
    href: "/admin/brands",
    label: "Brands",
    description: "Brand CRUD, media paths, and catalog metadata.",
    icon: Building2,
    group: "Catalog",
  },
  {
    href: "/admin/warehouses",
    label: "Warehouses",
    description: "Warehouse inventory, stock reservations, availability.",
    icon: Warehouse,
    group: "Inventory",
  },
  {
    href: "/admin/users",
    label: "Users",
    description: "Manage admin accounts, hierarchy, brand assignments.",
    icon: Users,
    group: "Admin",
  },
  {
    href: "/admin/roles",
    label: "Roles",
    description: "Role CRUD, permission bundles, RBAC config.",
    icon: Settings2,
    group: "Admin",
    roles: ["super_admin", "admin"],
  },
  {
    href: "/admin/imports",
    label: "Imports",
    description: "CSV/XLSX import jobs, legacy SQL migration, bulk ops.",
    icon: Upload,
    group: "Tools",
  },
  {
    href: "/admin/sheet",
    label: "Sheet Lab",
    description: "Upload CSV/XLSX, auto-filter columns, calibrate against live catalog.",
    icon: FileSpreadsheet,
    group: "Tools",
    badge: "NEW",
  },
  {
    href: "/admin/catalogs",
    label: "Catalogs",
    description: "PDF, PPT, and catalog generation jobs.",
    icon: ClipboardList,
    group: "Tools",
  },
];

export const MEGA_MENU_GROUPS: Record<string, AdminNavItem[]> = {
  Catalog: ADMIN_NAV_ITEMS.filter((item) => item.group === "Catalog"),
  Inventory: ADMIN_NAV_ITEMS.filter((item) => item.group === "Inventory"),
  Orders: ADMIN_NAV_ITEMS.filter((item) => item.group === "Orders"),
  Admin: ADMIN_NAV_ITEMS.filter((item) => item.group === "Admin"),
  Tools: ADMIN_NAV_ITEMS.filter((item) => item.group === "Tools"),
};

export const ADMIN_COMMAND_ITEMS: AdminCommandItem[] = [
  {
    id: "nav-dashboard",
    href: "/admin",
    label: "Dashboard",
    description: "Admin overview with live Mongo-backed stats.",
    icon: LayoutDashboard,
    group: "Navigate",
    keywords: ["home", "overview", "stats", "kpi"],
  },
  {
    id: "nav-orders",
    href: "/admin/orders",
    label: "Orders",
    description: "Order pipeline with workflow status and discount totals.",
    icon: ShoppingBag,
    group: "Navigate",
    keywords: ["orders", "pipeline", "checkout", "approval"],
  },
  {
    id: "nav-products",
    href: "/admin/products",
    label: "Products Catalog",
    description: "Catalog explorer with advanced filtering and variant table.",
    icon: Package,
    group: "Navigate",
    keywords: ["products", "catalog", "sku", "variants", "inventory"],
  },
  {
    id: "nav-brands",
    href: "/admin/brands",
    label: "Brands",
    description: "Brand CRUD — Callaway, OGIO, Travis Mathew.",
    icon: Building2,
    group: "Navigate",
    keywords: ["brands", "callaway", "ogio", "travis", "apparel"],
  },
  {
    id: "nav-warehouses",
    href: "/admin/warehouses",
    label: "Warehouses",
    description: "WH88, WH90 and dynamic warehouse stock.",
    icon: Warehouse,
    group: "Navigate",
    keywords: ["warehouse", "wh88", "wh90", "stock", "inventory"],
  },
  {
    id: "nav-users",
    href: "/admin/users",
    label: "Users",
    description: "User accounts, roles, brand and warehouse assignments.",
    icon: Users,
    group: "Navigate",
    keywords: ["users", "accounts", "roles", "assignments"],
  },
  {
    id: "nav-roles",
    href: "/admin/roles",
    label: "Roles",
    description: "Permission bundles and RBAC matrix.",
    icon: Settings2,
    group: "Navigate",
    keywords: ["roles", "permissions", "rbac", "access"],
    roles: ["super_admin", "admin"],
  },
  {
    id: "nav-imports",
    href: "/admin/imports",
    label: "Imports",
    description: "Legacy SQL migration and import job console.",
    icon: Upload,
    group: "Navigate",
    keywords: ["imports", "migration", "sql", "csv", "bulk"],
  },
  {
    id: "nav-sheet",
    href: "/admin/sheet",
    label: "Sheet Lab",
    description: "Upload sheets, auto-filter columns, calibrate catalog data.",
    icon: FileSpreadsheet,
    group: "Navigate",
    keywords: ["sheet", "upload", "csv", "xlsx", "filter", "calibrate", "call-check"],
  },
  {
    id: "nav-catalogs",
    href: "/admin/catalogs",
    label: "Catalogs",
    description: "PDF/PPT catalog generation and download center.",
    icon: ClipboardList,
    group: "Navigate",
    keywords: ["catalogs", "pdf", "ppt", "download", "export"],
  },
  {
    id: "create-order",
    href: "/admin/orders/new",
    label: "Create Order",
    description: "New admin checkout with variant picking and discount modes.",
    icon: ShoppingBag,
    group: "Create",
    keywords: ["new order", "create", "checkout", "discount"],
  },
  {
    id: "create-product",
    href: "/admin/products/new",
    label: "Create Product",
    description: "New catalog entry with option definitions and variant generation.",
    icon: Package,
    group: "Create",
    keywords: ["new product", "create", "sku", "variant"],
  },
  {
    id: "export-products",
    href: "/api/admin/export/products",
    label: "Export Products CSV",
    description: "Download all products as CSV.",
    icon: Database,
    group: "Operations",
    keywords: ["export", "csv", "download", "products"],
  },
  {
    id: "export-orders",
    href: "/api/admin/export/orders",
    label: "Export Orders CSV",
    description: "Download all orders as CSV.",
    icon: Database,
    group: "Operations",
    keywords: ["export", "csv", "download", "orders"],
  },
  {
    id: "sheet-upload",
    href: "/admin/sheet",
    label: "Sheet Upload Lab",
    description: "Upload CSV/XLSX and calibrate against live catalog data.",
    icon: Table2,
    group: "Operations",
    keywords: ["upload", "sheet", "csv", "xlsx", "calibrate", "import", "filter"],
  },
  {
    id: "customizer",
    href: "/admin/customizer",
    label: "Wedge Configurator",
    description: "Opus wedge design pipeline with 4-stage modular config.",
    icon: Box,
    group: "Operations",
    keywords: ["customizer", "wedge", "opus", "configurator"],
  },
  {
    id: "analytics",
    href: "/admin",
    label: "Analytics Overview",
    description: "Live KPIs across catalog, orders, and users.",
    icon: BarChart3,
    group: "Navigate",
    keywords: ["analytics", "stats", "kpi", "overview"],
  },
  {
    id: "migrate",
    href: "/admin/imports",
    label: "Legacy Migration",
    description: "SQL→Mongo migration job for legacy OMS data.",
    icon: FileCog,
    group: "Operations",
    keywords: ["migrate", "legacy", "sql", "oms", "import"],
  },
];
