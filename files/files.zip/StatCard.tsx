import {LucideIcon} from "lucide-react";

export function StatCard({
  label,
  value,
  hint,
  icon: Icon,
}: {
  label: string;
  value: string | number;
  hint?: string;
  icon: LucideIcon;
}) {
  return (
    <div className="rounded-2xl border border-white/8 bg-[#0d0d0d] p-4 hover:border-white/12 transition-colors">
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <p className="text-[10px] font-semibold uppercase tracking-[0.2em] text-white/30">{label}</p>
          <p className="mt-2 text-[1.75rem] font-semibold tracking-tight text-white/90 tabular-nums leading-none">{value}</p>
        </div>
        <div className="shrink-0 flex h-9 w-9 items-center justify-center rounded-xl border border-primary/20 bg-primary/10 text-primary/80">
          <Icon size={16} />
        </div>
      </div>
      {hint && <p className="mt-3 text-[11px] leading-5 text-white/30">{hint}</p>}
    </div>
  );
}
