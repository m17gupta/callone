"use client";

import {useCallback, useMemo, useRef, useState} from "react";
import {
  AlertCircle,
  ArrowUpDown,
  Check,
  CheckCircle2,
  ChevronDown,
  ChevronsUpDown,
  Download,
  Filter,
  Plus,
  RefreshCw,
  Table2,
  Trash2,
  Upload,
  X,
  XCircle,
  Zap,
} from "lucide-react";
import clsx from "clsx";

// ─── Types ─────────────────────────────────────────────────────────────────

type CatalogContext = {
  brands: Array<{id: string; name: string; code: string}>;
  products: Array<{id: string; name: string; baseSku: string; category: string}>;
  skus: string[];
  warehouses: Array<{id: string; code: string; name: string}>;
};

type ColumnFilter = {
  col: string;
  operator: FilterOperator;
  value: string;
  logic: "AND" | "OR";
};

type FilterOperator =
  | "contains"
  | "not_contains"
  | "equals"
  | "not_equals"
  | "starts_with"
  | "ends_with"
  | "greater_than"
  | "less_than"
  | "is_empty"
  | "is_not_empty";

type SortState = {col: string; dir: "asc" | "desc"} | null;

type CalibrationResult = "match" | "mismatch" | "unknown" | "new";

// ─── Constants ─────────────────────────────────────────────────────────────

const FILTER_OPERATORS: Array<{value: FilterOperator; label: string}> = [
  {value: "contains", label: "Contains"},
  {value: "not_contains", label: "Does not contain"},
  {value: "equals", label: "Equals"},
  {value: "not_equals", label: "Not equals"},
  {value: "starts_with", label: "Starts with"},
  {value: "ends_with", label: "Ends with"},
  {value: "greater_than", label: "Greater than"},
  {value: "less_than", label: "Less than"},
  {value: "is_empty", label: "Is empty"},
  {value: "is_not_empty", label: "Is not empty"},
];

const DEFAULT_CSV = `SKU,Product Name,Brand,Category,Warehouse,Stock,Price,Status
CGAPP-POLO-001-BLU-S,Tour Performance Polo / Blue / S,Callaway Apparel,Polos,WH88,24,2999,active
CGAPP-POLO-001-BLU-M,Tour Performance Polo / Blue / M,Callaway Apparel,Polos,WH88,18,2999,active
CGAPP-POLO-001-WHT-S,Tour Performance Polo / White / S,Callaway Apparel,Polos,WH90,12,2999,active
CGHG-DRIVER-001,Paradym Driver 9°,Callaway Hardgoods,Drivers,WH88,8,42999,active
CGHG-IRON-001-4I,Apex 24 Irons / 4-Iron,Callaway Hardgoods,Irons,WH90,5,12999,active
OGIO-BAG-001-BLK,Fuse 14 Cart Bag / Black,OGIO,Bags,WH88,15,18999,active
OGIO-BAG-001-RED,Fuse 14 Cart Bag / Red,OGIO,Bags,WH88,7,18999,active
TM-POLO-001-GRN-L,Harmon Face Classic Polo / Green / L,Travis Mathew,Polos,WH88,22,5999,active
TM-POLO-001-NAV-M,Harmon Face Classic Polo / Navy / M,Travis Mathew,Polos,WH90,16,5999,active
CGAPP-SHORT-001-BLK-S,Tech Short / Black / S,Callaway Apparel,Shorts,WH88,30,3499,active
CGAPP-SHORT-001-GRY-M,Tech Short / Grey / M,Callaway Apparel,Shorts,WH88,28,3499,active
CGHG-WEDGE-001-58,Opus Wedge 58°,Callaway Hardgoods,Wedges,WH88,10,14999,active
CGHG-WEDGE-001-60,Opus Wedge 60°,Callaway Hardgoods,Wedges,WH88,6,14999,active
OGIO-CAP-001-WHT,Gotcha Cap / White,OGIO,Accessories,WH90,40,2999,active
TM-JACKET-001-NAV-L,Bionic Jacket / Navy / L,Travis Mathew,Outerwear,WH90,12,11999,active
CGAPP-POLO-002-RED-XL,Swing Tech Polo / Red / XL,Callaway Apparel,Polos,WH88,0,3199,out_of_stock
CGHG-PUTTER-001,Odyssey White Hot OG Putter,Callaway Hardgoods,Putters,WH88,4,22999,active
CGAPP-TROUSER-001-BLK-32,Performance Trouser / Black / 32,Callaway Apparel,Trousers,WH88,9,4999,active
TM-TEE-001-WHT-M,Coto Tee / White / M,Travis Mathew,T-Shirts,WH90,35,2499,active
OGIO-TOWEL-001,Lay Low Towel,OGIO,Accessories,WH88,50,999,active`;

const PAGE_SIZES = [25, 50, 100, "All"] as const;

// ─── Utilities ──────────────────────────────────────────────────────────────

function parseCSV(text: string): {columns: string[]; rows: Record<string, string>[]} {
  const lines = text.trim().split("\n");
  if (lines.length < 2) return {columns: [], rows: []};
  const columns = lines[0].split(",").map((c) => c.trim().replace(/^"|"$/g, ""));
  const rows = lines.slice(1).map((line) => {
    const values = line.split(",").map((v) => v.trim().replace(/^"|"$/g, ""));
    return Object.fromEntries(columns.map((col, i) => [col, values[i] ?? ""]));
  });
  return {columns, rows};
}

function applyFilter(value: string, op: FilterOperator, filterVal: string): boolean {
  const v = value.toLowerCase();
  const fv = filterVal.toLowerCase();
  switch (op) {
    case "contains": return v.includes(fv);
    case "not_contains": return !v.includes(fv);
    case "equals": return v === fv;
    case "not_equals": return v !== fv;
    case "starts_with": return v.startsWith(fv);
    case "ends_with": return v.endsWith(fv);
    case "greater_than": return parseFloat(value) > parseFloat(filterVal);
    case "less_than": return parseFloat(value) < parseFloat(filterVal);
    case "is_empty": return !value.trim();
    case "is_not_empty": return !!value.trim();
    default: return true;
  }
}

function downloadCSV(columns: string[], rows: Record<string, string>[], filename: string) {
  const header = columns.join(",");
  const body = rows.map((row) => columns.map((col) => `"${(row[col] ?? "").replace(/"/g, '""')}"`).join(",")).join("\n");
  const blob = new Blob([`${header}\n${body}`], {type: "text/csv"});
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

function calibrateRow(
  row: Record<string, string>,
  columns: string[],
  catalogContext: CatalogContext
): CalibrationResult {
  // Find SKU column
  const skuCol = columns.find((c) => c.toLowerCase().includes("sku"));
  if (!skuCol) return "unknown";
  const sku = (row[skuCol] ?? "").trim().toUpperCase();
  if (!sku) return "unknown";
  const allSkus = catalogContext.skus.map((s) => s.toUpperCase());
  if (allSkus.includes(sku)) return "match";
  // Check base SKU pattern
  const baseMatch = catalogContext.products.some((p) =>
    sku.startsWith(p.baseSku.toUpperCase())
  );
  if (baseMatch) return "match";
  // Check warehouse
  const whCol = columns.find((c) => c.toLowerCase().includes("warehouse") || c.toLowerCase() === "wh");
  if (whCol) {
    const wh = (row[whCol] ?? "").trim().toUpperCase();
    const validWhs = catalogContext.warehouses.map((w) => w.code.toUpperCase());
    if (wh && !validWhs.includes(wh)) return "mismatch";
  }
  return "new";
}

// ─── Component ──────────────────────────────────────────────────────────────

export function SheetLabWorkspace({catalogContext}: {catalogContext: CatalogContext}) {
  const fileRef = useRef<HTMLInputElement>(null);
  const [columns, setColumns] = useState<string[]>([]);
  const [allRows, setAllRows] = useState<Record<string, string>[]>([]);
  const [fileName, setFileName] = useState<string>("");
  const [activeFilters, setActiveFilters] = useState<ColumnFilter[]>([]);
  const [filterPanelOpen, setFilterPanelOpen] = useState(false);
  const [sort, setSort] = useState<SortState>(null);
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState<number | "All">(50);
  const [selectedIds, setSelectedIds] = useState<Set<number>>(new Set());
  const [calibrateMode, setCalibrateMode] = useState(false);
  const [savedCount, setSavedCount] = useState<number | null>(null);
  const [quickFilter, setQuickFilter] = useState("");
  const [editingFilterIdx, setEditingFilterIdx] = useState<number | null>(null);

  const loadCSV = useCallback((text: string, name: string) => {
    const {columns, rows} = parseCSV(text);
    setColumns(columns);
    setAllRows(rows);
    setFileName(name);
    setPage(1);
    setSelectedIds(new Set());
    setActiveFilters([]);
    setSort(null);
  }, []);

  const handleFile = useCallback(
    (file: File) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        const text = e.target?.result as string;
        loadCSV(text, file.name);
      };
      reader.readAsText(file);
    },
    [loadCSV]
  );

  const handleDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault();
      const file = e.dataTransfer.files[0];
      if (file) handleFile(file);
    },
    [handleFile]
  );

  const loadDefault = () => loadCSV(DEFAULT_CSV, "sample-catalog.csv");

  const filteredRows = useMemo(() => {
    let rows = allRows;

    // Quick filter
    if (quickFilter) {
      const q = quickFilter.toLowerCase();
      rows = rows.filter((row) =>
        columns.some((col) => (row[col] ?? "").toLowerCase().includes(q))
      );
    }

    // Column filters
    if (activeFilters.length > 0) {
      rows = rows.filter((row) => {
        const results = activeFilters.map((f) =>
          applyFilter(row[f.col] ?? "", f.operator, f.value)
        );
        // First filter is always considered as AND with the row itself
        let pass = results[0] ?? true;
        for (let i = 1; i < activeFilters.length; i++) {
          if (activeFilters[i].logic === "OR") {
            pass = pass || results[i];
          } else {
            pass = pass && results[i];
          }
        }
        return pass;
      });
    }

    // Sort
    if (sort) {
      rows = [...rows].sort((a, b) => {
        const av = a[sort.col] ?? "";
        const bv = b[sort.col] ?? "";
        const na = parseFloat(av);
        const nb = parseFloat(bv);
        const cmp = !isNaN(na) && !isNaN(nb) ? na - nb : av.localeCompare(bv);
        return sort.dir === "asc" ? cmp : -cmp;
      });
    }

    return rows;
  }, [allRows, columns, quickFilter, activeFilters, sort]);

  const calibrationMap = useMemo(() => {
    if (!calibrateMode) return new Map<number, CalibrationResult>();
    const map = new Map<number, CalibrationResult>();
    filteredRows.forEach((row, i) => {
      map.set(i, calibrateRow(row, columns, catalogContext));
    });
    return map;
  }, [calibrateMode, filteredRows, columns, catalogContext]);

  const paginatedRows = useMemo(() => {
    if (pageSize === "All") return filteredRows;
    return filteredRows.slice((page - 1) * pageSize, page * pageSize);
  }, [filteredRows, page, pageSize]);

  const totalPages = pageSize === "All" ? 1 : Math.max(1, Math.ceil(filteredRows.length / pageSize));

  const allPageSelected =
    paginatedRows.length > 0 &&
    paginatedRows.every((_, i) => {
      const globalIdx = pageSize === "All" ? i : (page - 1) * (pageSize as number) + i;
      return selectedIds.has(globalIdx);
    });

  const addFilter = () => {
    setActiveFilters((prev) => [
      ...prev,
      {col: columns[0] ?? "", operator: "contains", value: "", logic: "AND"},
    ]);
    setFilterPanelOpen(true);
  };

  const removeFilter = (idx: number) => {
    setActiveFilters((prev) => prev.filter((_, i) => i !== idx));
  };

  const updateFilter = (idx: number, patch: Partial<ColumnFilter>) => {
    setActiveFilters((prev) =>
      prev.map((f, i) => (i === idx ? {...f, ...patch} : f))
    );
  };

  const calibSummary = useMemo(() => {
    const vals = [...calibrationMap.values()];
    return {
      match: vals.filter((v) => v === "match").length,
      mismatch: vals.filter((v) => v === "mismatch").length,
      new_: vals.filter((v) => v === "new").length,
      unknown: vals.filter((v) => v === "unknown").length,
    };
  }, [calibrationMap]);

  const CALIB_STYLES: Record<CalibrationResult, string> = {
    match: "border-l-2 border-l-emerald-500/60 bg-emerald-500/4",
    mismatch: "border-l-2 border-l-red-500/60 bg-red-500/4",
    new: "border-l-2 border-l-amber-500/60 bg-amber-500/4",
    unknown: "",
  };

  const CALIB_ICON: Record<CalibrationResult, React.ReactNode> = {
    match: <Check size={12} className="text-emerald-400" />,
    mismatch: <X size={12} className="text-red-400" />,
    new: <Plus size={12} className="text-amber-400" />,
    unknown: <span className="h-3 w-3 rounded-full border border-white/15 inline-block" />,
  };

  if (allRows.length === 0) {
    return (
      <div
        className="flex flex-col items-center justify-center rounded-2xl border-2 border-dashed border-white/10 bg-white/[0.015] min-h-[420px] text-center transition-colors hover:border-white/20 cursor-pointer"
        onDrop={handleDrop}
        onDragOver={(e) => e.preventDefault()}
        onClick={() => fileRef.current?.click()}
      >
        <input
          ref={fileRef}
          type="file"
          accept=".csv,.xlsx,.xls"
          className="hidden"
          onChange={(e) => e.target.files?.[0] && handleFile(e.target.files[0])}
        />
        <div className="flex h-16 w-16 items-center justify-center rounded-2xl border border-white/10 bg-white/5 mb-5">
          <Table2 size={28} className="text-white/30" />
        </div>
        <h3 className="text-lg font-semibold text-white/70 mb-2">Drop a CSV / XLSX here</h3>
        <p className="text-[13px] text-white/30 max-w-sm mb-6">
          Auto-detect columns, apply smart filters, and calibrate rows against your live catalog.
        </p>
        <div className="flex items-center gap-3">
          <button
            onClick={(e) => {
              e.stopPropagation();
              fileRef.current?.click();
            }}
            className="flex items-center gap-2 rounded-xl border border-white/15 bg-white/6 px-4 py-2.5 text-[13px] font-semibold text-white/70 hover:border-white/25 hover:text-white transition"
          >
            <Upload size={15} />
            Upload file
          </button>
          <button
            onClick={(e) => {
              e.stopPropagation();
              loadDefault();
            }}
            className="flex items-center gap-2 rounded-xl bg-primary px-4 py-2.5 text-[13px] font-semibold text-white shadow-[0_8px_24px_rgba(47,127,244,0.2)] hover:bg-primary/90 transition"
          >
            <Zap size={15} />
            Load sample catalog
          </button>
        </div>
        <p className="mt-5 text-[11px] text-white/20">
          Supports CSV, XLSX — columns auto-detected. Default sample has 20 rows across Callaway brands.
        </p>
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-3">
      {/* ── TOP TOOLBAR ── */}
      <div className="flex flex-col gap-2 rounded-2xl border border-white/8 bg-[#0d0d0d] p-3 lg:flex-row lg:items-center">
        {/* File info */}
        <div className="flex items-center gap-2.5">
          <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl border border-white/10 bg-white/5">
            <Table2 size={15} className="text-primary/80" />
          </div>
          <div>
            <p className="text-[12px] font-semibold text-white/80 leading-tight">{fileName}</p>
            <p className="text-[10px] text-white/30">
              {allRows.length} rows · {columns.length} columns
            </p>
          </div>
        </div>

        <div className="w-px h-6 bg-white/8 hidden lg:block" />

        {/* Quick filter */}
        <div className="relative flex-1 min-w-0 max-w-[360px]">
          <input
            type="text"
            placeholder="Quick filter all columns…"
            value={quickFilter}
            onChange={(e) => setQuickFilter(e.target.value)}
            className="h-9 w-full rounded-xl border border-white/10 bg-white/4 pl-3 pr-8 text-[12px] text-white placeholder:text-white/25 outline-none focus:border-primary/40 transition"
          />
          {quickFilter && (
            <button
              onClick={() => setQuickFilter("")}
              className="absolute right-2.5 top-1/2 -translate-y-1/2 text-white/30 hover:text-white/60"
            >
              <X size={12} />
            </button>
          )}
        </div>

        {/* Filter actions */}
        <div className="flex items-center gap-1.5 flex-wrap">
          <button
            onClick={addFilter}
            className={clsx(
              "flex items-center gap-1.5 rounded-xl border px-3 py-1.5 text-[12px] font-medium transition",
              activeFilters.length > 0
                ? "border-primary/40 bg-primary/10 text-primary"
                : "border-white/10 bg-white/4 text-white/50 hover:border-white/20 hover:text-white/80"
            )}
          >
            <Filter size={13} />
            Add filter
            {activeFilters.length > 0 && (
              <span className="flex h-4 w-4 items-center justify-center rounded-full bg-primary text-[9px] font-bold text-white">
                {activeFilters.length}
              </span>
            )}
          </button>

          <button
            onClick={() => setCalibrateMode((v) => !v)}
            className={clsx(
              "flex items-center gap-1.5 rounded-xl border px-3 py-1.5 text-[12px] font-medium transition",
              calibrateMode
                ? "border-emerald-400/30 bg-emerald-400/8 text-emerald-400"
                : "border-white/10 bg-white/4 text-white/50 hover:border-white/20 hover:text-white/80"
            )}
          >
            <Zap size={13} />
            Calibrate
          </button>

          <button
            onClick={() => {
              fileRef.current?.click();
            }}
            className="flex items-center gap-1.5 rounded-xl border border-white/10 bg-white/4 px-3 py-1.5 text-[12px] font-medium text-white/50 hover:border-white/20 hover:text-white/80 transition"
          >
            <RefreshCw size={13} />
            Replace
          </button>

          <button
            onClick={() => downloadCSV(columns, filteredRows, `export-${fileName}`)}
            className="flex items-center gap-1.5 rounded-xl border border-white/10 bg-white/4 px-3 py-1.5 text-[12px] font-medium text-white/50 hover:border-white/20 hover:text-white/80 transition"
          >
            <Download size={13} />
            Export
          </button>
        </div>

        <input
          ref={fileRef}
          type="file"
          accept=".csv,.xlsx,.xls"
          className="hidden"
          onChange={(e) => e.target.files?.[0] && handleFile(e.target.files[0])}
        />
      </div>

      {/* ── FILTER PANEL ── */}
      {filterPanelOpen && activeFilters.length > 0 && (
        <div className="rounded-2xl border border-white/8 bg-[#0d0d0d] p-3">
          <div className="flex items-center justify-between mb-3">
            <p className="text-[11px] font-semibold uppercase tracking-[0.2em] text-white/30">
              Active Filters ({activeFilters.length})
            </p>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setActiveFilters([])}
                className="text-[11px] text-white/30 hover:text-white/60 transition"
              >
                Clear all
              </button>
              <button
                onClick={() => setFilterPanelOpen(false)}
                className="text-white/30 hover:text-white/60"
              >
                <X size={14} />
              </button>
            </div>
          </div>
          <div className="space-y-2">
            {activeFilters.map((f, idx) => (
              <div
                key={idx}
                className="flex items-center gap-2 rounded-xl border border-white/8 bg-white/3 p-2 flex-wrap"
              >
                {idx > 0 && (
                  <button
                    onClick={() =>
                      updateFilter(idx, {logic: f.logic === "AND" ? "OR" : "AND"})
                    }
                    className="rounded-lg border border-white/10 bg-white/5 px-2 py-1 text-[10px] font-bold uppercase tracking-wider text-white/50 hover:text-primary transition w-10 text-center"
                  >
                    {f.logic}
                  </button>
                )}
                {idx === 0 && (
                  <span className="rounded-lg border border-white/8 bg-white/3 px-2 py-1 text-[10px] font-bold uppercase tracking-wider text-white/25 w-10 text-center">
                    IF
                  </span>
                )}
                <select
                  value={f.col}
                  onChange={(e) => updateFilter(idx, {col: e.target.value})}
                  className="h-8 rounded-lg border border-white/10 bg-white/5 px-2 text-[12px] text-white/70 outline-none flex-1 min-w-[120px]"
                >
                  {columns.map((col) => (
                    <option key={col} value={col}>{col}</option>
                  ))}
                </select>
                <select
                  value={f.operator}
                  onChange={(e) => updateFilter(idx, {operator: e.target.value as FilterOperator})}
                  className="h-8 rounded-lg border border-white/10 bg-white/5 px-2 text-[12px] text-white/70 outline-none flex-1 min-w-[140px]"
                >
                  {FILTER_OPERATORS.map((op) => (
                    <option key={op.value} value={op.value}>{op.label}</option>
                  ))}
                </select>
                {!["is_empty", "is_not_empty"].includes(f.operator) && (
                  <input
                    type="text"
                    placeholder="Value…"
                    value={f.value}
                    onChange={(e) => updateFilter(idx, {value: e.target.value})}
                    className="h-8 rounded-lg border border-white/10 bg-white/5 px-2.5 text-[12px] text-white placeholder:text-white/20 outline-none focus:border-primary/40 transition flex-1 min-w-[100px]"
                  />
                )}
                <button
                  onClick={() => removeFilter(idx)}
                  className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg border border-white/8 bg-white/3 text-white/30 hover:border-red-400/30 hover:text-red-400 transition"
                >
                  <Trash2 size={12} />
                </button>
              </div>
            ))}
            <button
              onClick={addFilter}
              className="flex items-center gap-1.5 rounded-xl border border-dashed border-white/10 px-3 py-2 text-[11px] text-white/30 hover:border-white/20 hover:text-white/55 transition w-full"
            >
              <Plus size={12} />
              Add another filter
            </button>
          </div>
        </div>
      )}

      {/* ── CALIBRATION SUMMARY ── */}
      {calibrateMode && (
        <div className="flex items-center gap-3 rounded-xl border border-white/8 bg-[#0d0d0d] p-3 flex-wrap">
          <p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-white/30 mr-2">
            Calibration
          </p>
          <CalibPill count={calibSummary.match} color="emerald" label="Matched" icon={<CheckCircle2 size={12} />} />
          <CalibPill count={calibSummary.mismatch} color="red" label="Mismatch" icon={<XCircle size={12} />} />
          <CalibPill count={calibSummary.new_} color="amber" label="New" icon={<Plus size={12} />} />
          <CalibPill count={calibSummary.unknown} color="gray" label="Unknown" icon={<AlertCircle size={12} />} />
          <p className="ml-auto text-[11px] text-white/25">
            Checking against {catalogContext.skus.length} live SKUs, {catalogContext.products.length} products
          </p>
        </div>
      )}

      {/* ── STATS ROW ── */}
      <div className="flex items-center justify-between px-1">
        <p className="text-[11px] text-white/30">
          Showing{" "}
          <span className="text-white/60 font-semibold">{filteredRows.length}</span>{" "}
          of {allRows.length} rows
          {(activeFilters.length > 0 || quickFilter) && (
            <span className="text-white/20"> (filtered)</span>
          )}
        </p>
        <div className="flex items-center gap-2">
          {selectedIds.size > 0 && (
            <span className="text-[11px] text-white/40">
              {selectedIds.size} selected
            </span>
          )}
          <span className="text-[11px] text-white/25">Rows:</span>
          {PAGE_SIZES.map((s) => (
            <button
              key={s}
              onClick={() => {
                setPageSize(s);
                setPage(1);
              }}
              className={clsx(
                "rounded-lg px-2 py-0.5 text-[11px] font-medium transition",
                pageSize === s
                  ? "bg-white/10 text-white/70"
                  : "text-white/25 hover:text-white/50"
              )}
            >
              {s}
            </button>
          ))}
        </div>
      </div>

      {/* ── TABLE ── */}
      <div className="rounded-2xl border border-white/8 bg-[#0d0d0d] overflow-hidden">
        <div className="overflow-auto max-h-[65vh]">
          <table className="min-w-full text-[12px]">
            <thead className="sticky top-0 z-10 bg-[#080808] border-b border-white/8">
              <tr>
                <th className="w-10 px-3 py-2.5">
                  <input
                    type="checkbox"
                    checked={allPageSelected}
                    onChange={() => {
                      if (allPageSelected) {
                        setSelectedIds((s) => {
                          const next = new Set(s);
                          paginatedRows.forEach((_, i) => {
                            const gi = pageSize === "All" ? i : (page - 1) * (pageSize as number) + i;
                            next.delete(gi);
                          });
                          return next;
                        });
                      } else {
                        setSelectedIds((s) => {
                          const next = new Set(s);
                          paginatedRows.forEach((_, i) => {
                            const gi = pageSize === "All" ? i : (page - 1) * (pageSize as number) + i;
                            next.add(gi);
                          });
                          return next;
                        });
                      }
                    }}
                    className="h-3.5 w-3.5 rounded border-white/20 bg-white/5 accent-primary cursor-pointer"
                  />
                </th>
                {calibrateMode && (
                  <th className="w-8 px-2 py-2.5 text-[9px] font-semibold uppercase tracking-wider text-white/25">
                    ✓
                  </th>
                )}
                <th className="px-3 py-2.5 text-[9px] font-semibold uppercase tracking-wider text-white/25 text-right w-10">
                  #
                </th>
                {columns.map((col) => (
                  <th
                    key={col}
                    className="px-3 py-2.5 text-left text-[9px] font-semibold uppercase tracking-wider text-white/30 whitespace-nowrap cursor-pointer hover:text-white/55 transition select-none"
                    onClick={() =>
                      setSort((s) =>
                        s?.col === col
                          ? s.dir === "asc"
                            ? {col, dir: "desc"}
                            : null
                          : {col, dir: "asc"}
                      )
                    }
                  >
                    <span className="inline-flex items-center gap-1">
                      {col}
                      {sort?.col === col ? (
                        <ArrowUpDown
                          size={10}
                          className={clsx("text-primary", sort.dir === "desc" && "rotate-180")}
                        />
                      ) : (
                        <ChevronsUpDown size={10} className="text-white/15" />
                      )}
                    </span>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {paginatedRows.map((row, i) => {
                const globalIdx = pageSize === "All" ? i : (page - 1) * (pageSize as number) + i;
                const isSelected = selectedIds.has(globalIdx);
                const calib = calibrationMap.get(globalIdx);

                return (
                  <tr
                    key={globalIdx}
                    className={clsx(
                      "border-b border-white/4 transition-colors group",
                      isSelected ? "bg-primary/6" : "hover:bg-white/[0.02]",
                      calibrateMode && calib && CALIB_STYLES[calib]
                    )}
                  >
                    <td className="w-10 px-3 py-2">
                      <input
                        type="checkbox"
                        checked={isSelected}
                        onChange={() => {
                          setSelectedIds((s) => {
                            const next = new Set(s);
                            if (isSelected) next.delete(globalIdx);
                            else next.add(globalIdx);
                            return next;
                          });
                        }}
                        className="h-3.5 w-3.5 rounded border-white/20 bg-white/5 accent-primary cursor-pointer"
                      />
                    </td>
                    {calibrateMode && (
                      <td className="px-2 py-2">
                        <div className="flex items-center justify-center">
                          {calib ? CALIB_ICON[calib] : null}
                        </div>
                      </td>
                    )}
                    <td className="px-3 py-2 text-right font-mono text-[10px] text-white/20">
                      {globalIdx + 1}
                    </td>
                    {columns.map((col) => (
                      <td key={col} className="px-3 py-2 text-white/65 whitespace-nowrap max-w-[200px] overflow-hidden text-ellipsis">
                        {row[col] ?? ""}
                      </td>
                    ))}
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {/* ── PAGINATION ── */}
        {pageSize !== "All" && totalPages > 1 && (
          <div className="flex items-center justify-between border-t border-white/8 px-4 py-2.5">
            <p className="text-[11px] text-white/30">
              Page <span className="text-white/55 font-semibold">{page}</span> of{" "}
              <span className="text-white/55 font-semibold">{totalPages}</span>
            </p>
            <div className="flex items-center gap-1">
              <button
                onClick={() => setPage(1)}
                disabled={page === 1}
                className="flex h-6 min-w-6 items-center justify-center rounded border border-white/8 px-1.5 text-[11px] text-white/30 hover:text-white/60 disabled:opacity-25 transition"
              >
                «
              </button>
              <button
                onClick={() => setPage((p) => p - 1)}
                disabled={page === 1}
                className="flex h-6 min-w-6 items-center justify-center rounded border border-white/8 px-1.5 text-[11px] text-white/30 hover:text-white/60 disabled:opacity-25 transition"
              >
                ‹
              </button>
              {Array.from({length: Math.min(5, totalPages)}, (_, i) => {
                const pg = Math.max(1, Math.min(totalPages - 4, page - 2)) + i;
                return (
                  <button
                    key={pg}
                    onClick={() => setPage(pg)}
                    className={clsx(
                      "flex h-6 min-w-6 items-center justify-center rounded border px-1.5 text-[11px] font-semibold transition",
                      pg === page
                        ? "border-primary/40 bg-primary/15 text-primary"
                        : "border-white/8 bg-white/3 text-white/30 hover:border-white/16 hover:text-white/65"
                    )}
                  >
                    {pg}
                  </button>
                );
              })}
              <button
                onClick={() => setPage((p) => p + 1)}
                disabled={page === totalPages}
                className="flex h-6 min-w-6 items-center justify-center rounded border border-white/8 px-1.5 text-[11px] text-white/30 hover:text-white/60 disabled:opacity-25 transition"
              >
                ›
              </button>
              <button
                onClick={() => setPage(totalPages)}
                disabled={page === totalPages}
                className="flex h-6 min-w-6 items-center justify-center rounded border border-white/8 px-1.5 text-[11px] text-white/30 hover:text-white/60 disabled:opacity-25 transition"
              >
                »
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

function CalibPill({
  count,
  color,
  label,
  icon,
}: {
  count: number;
  color: "emerald" | "red" | "amber" | "gray";
  label: string;
  icon: React.ReactNode;
}) {
  const styles = {
    emerald: "border-emerald-500/20 bg-emerald-500/8 text-emerald-400",
    red: "border-red-500/20 bg-red-500/8 text-red-400",
    amber: "border-amber-500/20 bg-amber-500/8 text-amber-400",
    gray: "border-white/10 bg-white/5 text-white/35",
  };
  return (
    <span
      className={clsx(
        "flex items-center gap-1.5 rounded-lg border px-2.5 py-1 text-[11px] font-semibold",
        styles[color]
      )}
    >
      {icon}
      <span className="font-mono">{count}</span>
      {label}
    </span>
  );
}
