type DataTableProps = {
  headers: string[];
  children: React.ReactNode;
};

export function DataTable({headers, children}: DataTableProps) {
  return (
    <div className="overflow-hidden rounded-xl border border-white/8">
      <div className="overflow-x-auto">
        <table className="min-w-full text-left text-[12px]">
          <thead className="bg-[#080808] border-b border-white/8">
            <tr>
              {headers.map((header) => (
                <th
                  key={header}
                  className="whitespace-nowrap px-4 py-3 text-[9px] font-semibold uppercase tracking-[0.2em] text-white/30"
                >
                  {header}
                </th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-white/5 [&_tr]:transition-colors [&_tr:hover]:bg-white/[0.025]">
            {children}
          </tbody>
        </table>
      </div>
    </div>
  );
}
