# CallawayOne

> Admin-first Next.js 14 + MongoDB rebuild of the legacy Callaway OMS.
> Black-glass digital aesthetic. Dense tables. Instant search. Calibrated import workflows.

Replaces:
- `OLD/CallaWayManagement` (React.js frontend)
- `OLD/CallawayManagementServer` (Node.js API)
- `u683660902_calloms_full.sql` (MySQL data)
- `OLD/call-check` (standalone sheet upload tester — now fully absorbed into `/admin/sheet`)

---

## Table of Contents

- [Project Overview](#project-overview)
- [Current Status](#current-status)
- [Architecture Decisions](#architecture-decisions)
- [Design System](#design-system)
- [Role Matrix](#role-matrix)
- [Admin Route Map](#admin-route-map)
- [Collections](#collections)
- [Sheet Lab — call-check Parity](#sheet-lab--call-check-parity)
- [Warehouse Rules](#warehouse-rules)
- [Discount Logic](#discount-logic)
- [Import Export PDF Catalog Scope](#import-export-pdf-catalog-scope)
- [Migration Strategy](#migration-strategy)
- [Sample Documents](#sample-documents)
- [Folder Structure](#folder-structure)
- [Environment Setup](#environment-setup)
- [Scripts](#scripts)
- [Testing](#testing)
- [Delivery Phases](#delivery-phases)
- [Known Gaps](#known-gaps)
- [AI Integration Scope](#ai-integration-scope)

---

## Project Overview

CallawayOne is the monolithic replacement for the legacy OMS. Normalized into reusable admin modules:

| Module | Legacy Reality | CallawayOne Direction |
|---|---|---|
| Auth | Demo role switching | NextAuth credentials + Mongo RBAC |
| Brands | Brand-specific code paths | Shared `brands` collection + brand-aware admin |
| Products | Separate MySQL tables per brand | Unified `products` + generated `variants` |
| Warehouses | `stock_88` / `stock_90` columns | `warehouses` + `inventoryLevels` + `inventoryMovements` |
| Blocked Qty | Legacy blocked qty rows | `blockedStock` + availability-aware reservations |
| Orders | Snapshot-heavy relational flow | Mongo `orders` with pricing snapshots + timeline |
| Exports | CSV/PDF/catalog expectations | CSV exports live; PDF/catalog pending |
| Sheet Upload | `OLD/call-check` separate app | `/admin/sheet` — integrated Sheet Lab with calibration |

---

## Current Status

### ✅ Implemented

- Next.js App Router admin shell — full-width, sticky header, mega navigation, dark glass aesthetic
- NextAuth credentials backed by MongoDB + bcrypt
- Middleware role restriction for `/admin`
- Bootstrap seeding for roles, brands, warehouses, users
- CRUD for: Brands, Warehouses, Roles, Users, Products, Orders
- Variable product generation from option definitions
- Warehouse-level inventory per variant
- Blocked-stock aware order creation, reservation, release, shipment
- CSV export for all major entities
- SQL migration script foundation
- **Product Catalog Explorer** — client-side filtering, sorting, pagination, checkboxes, attribute filters, applied filter chips
- **Sheet Lab** (`/admin/sheet`) — CSV/XLSX upload, auto-column detection, per-column conditional filters with AND/OR logic, calibration against live catalog SKUs, export filtered rows
- Mega navigation with grouped dropdown panels
- Instant command search (⌘K) with group scoping

### 🔄 Foundation Only (not full UI)

- Imports page — route exists; UI-driven import jobs pending
- Catalogs page — route exists; PDF/PPT generation pending
- Order approval multi-actor parity — status update exists; approval UI pending

### ❌ Not Yet

- File uploads for brand/product/order media
- PDF order export
- Catalog/PPT generation
- Bulk update screens
- Audit log screens
- Email template management
- Public storefront

---

## Architecture Decisions

### 1. Admin-first, full-width rendering

`/admin/*` is server-rendered and force-dynamic. Full-width layout — no `max-w` ceiling — suited for dense spreadsheet-style tables. Sticky header + sticky table headers via CSS `position: sticky`.

### 2. Auth split

- `src/middleware.ts` — token-only route protection (edge-safe)
- `src/lib/auth/options.ts` — full NextAuth credentials (Node, bcrypt)
- `src/lib/auth/session.ts` — server-side session guard for actions and routes

### 3. Client-side catalog explorer

Products page uses a server component to fetch + serialize data, then passes it to `<ProductCatalog>` (client component) for filtering, sorting, pagination, and selection entirely in-browser. No round-trips per filter action.

### 4. Sheet Lab — call-check absorption

`OLD/call-check` was a standalone React+ag-grid app for CSV upload with per-column filters. Sheet Lab (`/admin/sheet`) absorbs and extends that concept:

- Pure client-side parsing (no server upload required for local exploration)
- Auto-detects all columns from header row
- Per-column conditional filters with AND/OR chaining
- Quick filter across all columns simultaneously
- Calibration mode: cross-references every row against live Mongo SKUs, products, and warehouses
- Color-coded: ✓ Match / ✗ Mismatch / + New / ? Unknown
- Export filtered view back to CSV
- Default sample CSV (20 rows across all 4 Callaway brands)

### 5. Unified catalog model

Replaces brand-specific MySQL tables:

- `products` → shared product definition
- `variants` → one SKU per option combination
- `inventoryLevels` → stock per warehouse per variant
- `blockedStock` → legacy and manual blocked quantities

### 6. Snapshot-based orders

Orders keep line pricing and participant snapshots. Preserves legacy OMS behavior — financials stay stable after user or pricing changes.

### 7. Local media

All media under `public/images/*`. Media abstraction layer allows S3 swap later.

---

## Design System

CallawayOne uses a **dark-first, black-glass digital aesthetic**:

| Token | Value | Usage |
|---|---|---|
| `--background` | `#050505` | App canvas |
| `--surface` | `#0d0d0d` | Card backgrounds |
| `--surface-muted` | `#111111` | Toolbar, header backgrounds |
| `--primary` | `#3b82f6` | Actions, highlights, active states |
| `--border` | `rgba(255,255,255,0.08)` | Subtle dividers |
| `--foreground` | `#e8e8ea` | Primary text |

### Visual patterns

- **Glass panels** — `backdrop-filter: blur(20px)` + semi-transparent backgrounds
- **Sticky header** — compresses on scroll, translucent blur
- **Mega menu** — group-categorized dropdowns with icon + description rows
- **Data tables** — sticky `<thead>`, zebra hover, row checkboxes, column sort
- **Filter chips** — applied-filter badges with individual cancel controls
- **Status badges** — color-coded: `emerald` active / `amber` draft / `muted` archived
- **Mono tabular nums** — all numeric table cells use tabular font features

### Typography

Inter (system fallback) with `font-feature-settings: "ss01", "ss02", "cv01"` for clean reading at density.

### Motion

Framer Motion for: page mount fade-in, mega menu entrance, mobile drawer slide, search overlay. CSS transitions for: hover states, filter chip removals, row highlights.

---

## Role Matrix

| Route / Capability | super_admin | admin | manager | sales_rep | retailer |
|---|---|---|---|---|---|
| `/login` | ✅ | ✅ | ✅ | ✅ | ✅ |
| `/admin` shell | ✅ | ✅ | ✅ | ✅ | ❌ |
| Brands CRUD | ✅ | ✅ | ✅ | ✅ | ❌ |
| Products CRUD | ✅ | ✅ | ✅ | ✅ | ❌ |
| Warehouse CRUD | ✅ | ✅ | ✅ | ✅ | ❌ |
| Users CRUD | ✅ | ✅ | ✅ | ✅ | ❌ |
| Roles CRUD | ✅ | ✅ | ❌ | ❌ | ❌ |
| Orders create/view | ✅ | ✅ | ✅ | ✅ | ❌ |
| Sheet Lab | ✅ | ✅ | ✅ | ✅ | ❌ |

---

## Admin Route Map

| Route | Status | Notes |
|---|---|---|
| `/login` | live | Credentials auth against Mongo users |
| `/admin` | live | Overview dashboard with live counts |
| `/admin/orders` | live | Order list and detail |
| `/admin/orders/new` | live | Admin checkout with availability-aware reservation |
| `/admin/orders/[id]` | live | Summary + timeline + status update |
| `/admin/products` | live | **Client-side catalog explorer** — filter, sort, paginate, select |
| `/admin/products/new` | live | Product create with variant generation |
| `/admin/products/[id]/edit` | live | Product edit |
| `/admin/brands` | live | Brand CRUD + export |
| `/admin/brands/[id]/edit` | live | Brand edit |
| `/admin/warehouses` | live | Warehouse CRUD + stock summary |
| `/admin/warehouses/[id]/edit` | live | Warehouse edit |
| `/admin/users` | live | User CRUD + assignments |
| `/admin/users/[id]/edit` | live | User edit |
| `/admin/roles` | live | Role CRUD + export |
| `/admin/roles/[id]/edit` | live | Role edit |
| `/admin/sheet` | **live** | **Sheet Lab** — CSV upload, auto-filter, calibration |
| `/admin/imports` | scaffold | UI import jobs pending |
| `/admin/catalogs` | scaffold | Catalog/PPT generation pending |
| `/admin/customizer` | placeholder | Wedge configurator demo |

---

## Collections

### `roles`
`key`, `name`, `description`, `permissions[]`, `isSystem`, `isActive`

### `users`
Auth identity + password hash, `roleId`, `roleKey`, `managerId`, `assignedBrandIds[]`, `assignedWarehouseIds[]`, status, designation, contact, code, GST, address

### `brands`
`name`, `slug`, `code`, website, descriptive metadata, brand media paths, active status

### `products`
Brand linkage, category, subcategory, product type, status, list price, tax, option definitions, media paths, legacy metadata

### `variants`
One per purchasable combination — SKU, title, option value map, MRP/GST/cost, lifecycle status

### `warehouses`
Code, name, location, priority, default flag, active flag

### `inventoryLevels`
Unique `variantId + warehouseId` — `onHand`, `reserved`, `blocked`, `available`

### `inventoryMovements`
Audit ledger — types: `import`, `adjustment`, `reservation`, `release`, `shipment`, `transfer`

### `blockedStock`
Legacy or manual blocked qty — `variantId` or fallback SKU, may be warehouse-specific or global

### `orders`
Participant snapshots, item snapshots, pricing snapshot, workflow status, notes timeline, attachments

---

## Sheet Lab — call-check Parity

`OLD/call-check` was a separate React + ag-grid proof-of-concept for upload/filter. Key behaviors absorbed:

| call-check Feature | Sheet Lab Implementation |
|---|---|
| CSV file upload | ✅ Drag-drop or file picker |
| Auto column detection | ✅ Header row parsing |
| Quick filter (search all) | ✅ `quickFilter` state across all columns |
| Per-column filters | ✅ `ColumnFilter[]` with operator select |
| Filter operators | ✅ contains, equals, starts_with, greater_than, is_empty, etc. |
| AND/OR logic | ✅ Logic toggle per filter after the first |
| Row selection | ✅ Checkbox per row + select-all page |
| Sorting | ✅ Click column header, asc/desc/clear |
| Save to Mongo | 🔄 Pending — calibration currently client-side |
| Default CSV | ✅ 20-row sample across all 4 brands |
| Row editing | 🔄 Pending — planned for next iteration |
| Calibration against catalog | ✅ SKU match/mismatch/new/unknown with color coding |
| Export filtered view | ✅ Download filtered rows as CSV |

**Key extension beyond call-check:** Calibration mode cross-references every row's SKU column against live Mongo `variants.sku` values and `products.baseSku` prefixes. Color-coded results show exactly which rows are catalog-matched, which are mismatched (invalid warehouse code, etc.), which are new (not in catalog), and which are ambiguous.

---

## Warehouse Rules

### Seeded warehouses
- `WH88` — Primary
- `WH90` — Secondary

### Availability formula

```
effective_available = max(0, onHand - reserved - blocked - warehouseBlocked - distributedGlobalBlocked)
```

### Order reservation behavior
- New orders reserve stock immediately
- Auto-assigns warehouse by priority if not selected
- Cancelled/rejected orders release reservations
- Completed orders convert reserved stock to shipment deduction
- Legacy imported orders do not auto-adjust current stock

---

## Discount Logic

`src/lib/utils/discounts.ts`

Supported modes: `inclusive`, `exclusive`, `flat`, `none`

Line-level discount applied first. Breakdown: `discountAmount`, `taxableAmount`, `taxAmount`, `finalAmount`. Order totals aggregate into `orders.pricing` snapshot.

---

## Import Export PDF Catalog Scope

### Live
CSV export routes: `/api/admin/export/brands|warehouses|roles|users|products|orders`

### Planned
- SQL migration (`u683660902_calloms_full.sql`) → brands, users, products, blocked stock, orders
- UI-driven CSV/XLSX imports with job tracking
- Blocked stock maintenance screens
- Order PDF generation
- Catalog/PPT generation
- Download center with job history

---

## Migration Strategy

### Source systems
- `OLD/CallaWayManagement` — React frontend
- `OLD/CallawayManagementServer` — Node API
- `u683660902_calloms_full.sql` — MySQL dump

### Mapping

| Legacy source | Target collection |
|---|---|
| `brands` | `brands` |
| `callaway_apparel` | `products` + `variants` + `inventoryLevels` |
| `callaway_hardgoods` | `products` + `variants` + `inventoryLevels` |
| `ogio` | `products` + `variants` + `inventoryLevels` |
| `travis` | `products` + `variants` + `inventoryLevels` |
| `blockedqty` rows | `blockedStock` |
| `users` / `managers` / `retailers` | `users` |
| Order tables | `orders` |

`stock_88` → `WH88`, `stock_90` → `WH90`, unscoped blocked → `blockedStock` with `warehouseId: null`

---

## Sample Documents

### Product

```json
{
  "name": "Tour Performance Polo",
  "slug": "tour-performance-polo",
  "baseSku": "CGAPP-POLO-001",
  "brandId": "brand_callaway_apparel",
  "category": "Polos",
  "productType": "apparel",
  "status": "active",
  "taxRate": 18,
  "listPrice": 2999,
  "optionDefinitions": [
    {"key": "color", "label": "Color", "values": ["Blue", "White"], "useForVariants": true},
    {"key": "size", "label": "Size", "values": ["S", "M", "L"], "useForVariants": true}
  ]
}
```

### Order

```json
{
  "orderNumber": "CO-12451245",
  "workflowStatus": "submitted",
  "items": [{
    "variantId": "variant_blue_s",
    "sku": "CGAPP-POLO-001-BLU-S",
    "quantity": 4,
    "mrp": 2999,
    "gstRate": 18,
    "lineDiscountValue": 22,
    "finalAmount": 9309.68
  }],
  "pricing": {
    "discountType": "inclusive",
    "discountValue": 22,
    "finalTotal": 9309.68
  }
}
```

---

## Folder Structure

```
callone/
├── public/images/{brands,catalogs,orders,products,users}/
├── src/
│   ├── app/
│   │   ├── admin/
│   │   │   ├── page.tsx                    # Dashboard
│   │   │   ├── orders/{page,new,[id]}/
│   │   │   ├── products/{page,new,[id]}/
│   │   │   ├── brands/{page,[id]}/
│   │   │   ├── warehouses/{page,[id]}/
│   │   │   ├── users/{page,[id]}/
│   │   │   ├── roles/{page,[id]}/
│   │   │   ├── sheet/page.tsx              # Sheet Lab ← call-check absorbed
│   │   │   ├── imports/page.tsx
│   │   │   └── catalogs/page.tsx
│   │   ├── api/admin/export/[entity]/
│   │   └── login/
│   ├── components/
│   │   ├── admin/
│   │   │   ├── DataTable.tsx
│   │   │   ├── PageHeader.tsx
│   │   │   ├── ProductCatalog.tsx          # Client-side catalog explorer
│   │   │   ├── SheetLabWorkspace.tsx       # Sheet Lab UI
│   │   │   ├── SectionCard.tsx
│   │   │   ├── StatCard.tsx
│   │   │   └── NewOrderForm.tsx
│   │   ├── auth/{LoginExperience,LoginForm,AuthProvider}/
│   │   ├── layout/AdminShell.tsx           # Mega menu, sticky, full-width
│   │   ├── ui/MegaSearch.tsx               # ⌘K command center
│   │   └── ThemeProvider.tsx
│   ├── lib/
│   │   ├── actions/{brands,products,orders,users,roles,warehouses}/
│   │   ├── admin/command-center.ts         # Nav + command items
│   │   ├── auth/{options,session,bootstrap}/
│   │   ├── db/{connection,models}/
│   │   └── utils/{discounts,inventory,variants,csv}/
│   ├── scripts/{seed,seed-sql}/
│   └── types/
├── docs/implementation_plan.md
├── OLD/                                    # Read-only legacy reference
├── PLAN.md
├── README.md
└── products-sample-db-schema.md
```

---

## Environment Setup

```bash
cp .env.example .env.local
# edit MONGODB_URI, NEXTAUTH_SECRET
npm install
npm run seed
npm run dev
```

```env
MONGODB_URI=mongodb+srv://<user>:<pass>@<cluster>.mongodb.net/callone
NEXTAUTH_SECRET=<openssl rand -base64 32>
CALLONE_BOOTSTRAP_ADMIN_EMAIL=admin@callone.local
CALLONE_BOOTSTRAP_ADMIN_PASSWORD=CalloneAdmin@123
```

---

## Scripts

| Script | Purpose |
|---|---|
| `npm run dev` | Next.js dev server |
| `npm run build` | Production build |
| `npm run lint` | ESLint |
| `npm run test` | Node test runner for pricing/inventory utils |
| `npm run seed` | Bootstrap sample data |
| `npm run seed:legacy` | SQL-to-Mongo migration pass |

---

## Testing

Automated coverage:
- Discount calculation (inclusive, exclusive, flat, none)
- Variant cartesian generation
- Warehouse availability distribution

Needed:
- Server action integration tests for CRUD
- Order lifecycle inventory tests
- Migration fixture validation vs sampled SQL rows
- E2E for product filter + sheet upload calibration flow

---

## Delivery Phases

| Phase | Status | Scope |
|---|---|---|
| Phase 1: Baseline + Auth | ✅ | Mongo auth, RBAC middleware, bootstrap |
| Phase 2: CRUD Foundation | ✅ | Brands, warehouses, roles, users, products, orders |
| Phase 3: Inventory + Checkout | ✅ (partial) | Reservation, release, shipment; approval UI pending |
| Phase 4: Catalog Explorer | ✅ | Client-side filter/sort/paginate/select + Sheet Lab |
| Phase 5: Import Parity | 🔄 | UI-driven imports, blocked stock UI, PDF exports |
| Phase 6: Catalog/PPT + Audit | ❌ | Generation jobs, download center, audit logs |
| Phase 7: Public Commerce | ❌ | Storefront, retailer checkout |

---

## Known Gaps

- Product forms are server-form based, not guided multi-step builder
- Order line editing is limited to creation + status; line items not editable post-creation
- Sheet Lab calibration is client-side; save-to-Mongo and row editing are next
- Upload handlers not live; media paths are path-first
- Migration needs validation against production SQL fixtures before live import

---

## AI Integration Scope

Planned AI touchpoints (not yet implemented):

| Feature | Approach |
|---|---|
| Sheet calibration suggestions | LLM maps ambiguous column names to catalog fields |
| Smart filter builder | Natural language → `ColumnFilter[]` conversion |
| Product description generation | From SKU + attributes → marketing copy |
| Order anomaly detection | Flag unusual discount or stock patterns |
| Catalog text generation | Auto-generate brand-specific product summaries for PDF catalogs |
| Demand forecasting hints | Surface low-stock SKUs likely to deplete before reorder |

The Sheet Lab is the natural entry point for AI intervention — calibration that currently uses exact SKU matching could use fuzzy matching with LLM assistance for `"New"` rows where the SKU pattern is close but not exact.

---

*CallawayOne — Next.js 14, MongoDB, Tailwind CSS v3, NextAuth v4*
*Black-glass digital aesthetic. Full-width admin. Sheet Lab with call-check parity.*
