import Link from "next/link";
import {ChevronLeft} from "lucide-react";

type PageHeaderProps = {
  title: string;
  description?: string;
  backHref?: string;
  action?: React.ReactNode;
};

export function PageHeader({title, description, backHref, action}: PageHeaderProps) {
  return (
    <div className="flex flex-col gap-3 lg:flex-row lg:items-end lg:justify-between">
      <div className="space-y-2">
        {backHref ? (
          <Link
            href={backHref}
            className="inline-flex items-center gap-1.5 rounded-lg border border-white/10 bg-white/4 px-2.5 py-1 text-[10px] font-semibold uppercase tracking-[0.18em] text-white/40 transition hover:text-white/70 hover:bg-white/8"
          >
            <ChevronLeft size={13} />
            Back
          </Link>
        ) : null}
        <div>
          {description && (
            <p className="text-[10px] font-semibold uppercase tracking-[0.22em] text-white/25 mb-1">
              {description}
            </p>
          )}
          <h1 className="text-[1.6rem] font-semibold tracking-tight text-white/90 leading-tight">
            {title}
          </h1>
        </div>
      </div>
      {action ? <div className="flex shrink-0 items-center gap-2">{action}</div> : null}
    </div>
  );
}
