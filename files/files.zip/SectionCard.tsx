type SectionCardProps = {
  title?: string;
  description?: string;
  action?: React.ReactNode;
  children: React.ReactNode;
  className?: string;
};

export function SectionCard({title, description, action, children, className}: SectionCardProps) {
  return (
    <section
      className={`overflow-hidden rounded-2xl border border-white/8 bg-[#0d0d0d] ${className ?? ""}`}
    >
      {(title || action) && (
        <div className="flex flex-col gap-3 border-b border-white/6 px-5 py-3.5 lg:flex-row lg:items-center lg:justify-between">
          <div>
            {title && (
              <h2 className="text-[14px] font-semibold text-white/80">{title}</h2>
            )}
            {description && (
              <p className="mt-0.5 text-[12px] leading-5 text-white/35">{description}</p>
            )}
          </div>
          {action && <div className="flex items-center gap-2">{action}</div>}
        </div>
      )}
      <div className="p-5">{children}</div>
    </section>
  );
}
